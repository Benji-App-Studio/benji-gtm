"use strict";
(() => {
  // chrome-extension/src/protocol.ts
  var FILE_PORT = "ad-library:file";

  // chrome-extension/src/offscreen.ts
  chrome.runtime.onConnect.addListener((port) => {
    if (port.name !== FILE_PORT) return;
    const parts = [];
    port.onMessage.addListener((message) => {
      if (typeof message.chunk === "string") parts.push(message.chunk);
      if (message.end) {
        const url = URL.createObjectURL(new Blob(parts, { type: "application/json" }));
        parts.length = 0;
        port.postMessage({ url });
      }
    });
  });
  chrome.runtime.onMessage.addListener((message) => {
    if (message?.type === "ad-library:revoke") URL.revokeObjectURL(message.url);
  });
})();
