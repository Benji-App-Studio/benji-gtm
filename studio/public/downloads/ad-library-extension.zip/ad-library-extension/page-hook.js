"use strict";
(() => {
  // scripts/meta-ad-library/src/shared.ts
  var COOLDOWN_MS = 6 * 60 * 60 * 1e3;
  var MIN_GAP_MS = 30 * 60 * 1e3;
  var PERSONAL_KEYS = /* @__PURE__ */ new Set(["viewer", "actor", "ad_library_user"]);
  var SESSION_FIELDS = /* @__PURE__ */ new Set([
    "fb_dtsg",
    "fb_dtsg_ag",
    "lsd",
    "jazoest",
    "__user",
    "__a",
    "__req",
    "__hs",
    "__hsi",
    "__dyn",
    "__csr",
    "__rev",
    "__s",
    "__spin_r",
    "__spin_b",
    "__spin_t",
    "__comet_req",
    "__ccg",
    "__jssesw",
    "__aaid",
    "__hsdp",
    "__hblp",
    "__sjsp",
    "dpr",
    "av",
    "server_timestamps",
    "cookie",
    "cookies",
    "set-cookie",
    "authorization"
  ]);
  function sanitize(value) {
    if (Array.isArray(value)) return value.map((item) => sanitize(item));
    if (value && typeof value === "object") {
      const out = {};
      for (const [key, child] of Object.entries(value)) {
        if (PERSONAL_KEYS.has(key) || SESSION_FIELDS.has(key.toLowerCase())) continue;
        out[key] = sanitize(child);
      }
      return out;
    }
    return value;
  }

  // scripts/meta-ad-library/src/network.ts
  function requestMeta(postData) {
    const out = { friendlyName: null, docId: null, variables: null };
    if (!postData) return out;
    let form;
    try {
      form = new URLSearchParams(postData);
    } catch {
      return out;
    }
    out.friendlyName = form.get("fb_api_req_friendly_name");
    out.docId = form.get("doc_id");
    const variables = form.get("variables");
    if (variables) {
      try {
        out.variables = sanitize(JSON.parse(variables));
      } catch {
        out.variables = null;
      }
      if (out.variables && typeof out.variables === "object") {
        for (const key of Object.keys(out.variables)) if (SESSION_FIELDS.has(key.toLowerCase())) delete out.variables[key];
      }
    }
    return out;
  }
  var isGraphql = (url) => {
    try {
      return new URL(url).pathname.startsWith("/api/graphql");
    } catch {
      return false;
    }
  };

  // chrome-extension/src/protocol.ts
  var HOOK_EVENT = "ad-library:graphql";

  // chrome-extension/src/page-hook.ts
  var absolute = (url) => {
    try {
      return new URL(url, location.href).href;
    } catch {
      return url;
    }
  };
  function bodyText(body) {
    if (typeof body === "string") return body;
    if (body instanceof URLSearchParams) return body.toString();
    if (body instanceof FormData) {
      const form = new URLSearchParams();
      body.forEach((value, key) => {
        if (typeof value === "string") form.append(key, value);
      });
      return form.toString();
    }
    return null;
  }
  function emit(url, status, contentType, postData, body) {
    const meta = requestMeta(postData);
    const payload = { url, status, contentType, friendlyName: meta.friendlyName, docId: meta.docId, variables: meta.variables, body, at: (/* @__PURE__ */ new Date()).toISOString() };
    document.dispatchEvent(new CustomEvent(HOOK_EVENT, { detail: JSON.stringify(payload) }));
  }
  var requests = /* @__PURE__ */ new WeakMap();
  var open = XMLHttpRequest.prototype.open;
  var send = XMLHttpRequest.prototype.send;
  XMLHttpRequest.prototype.open = function(method, url, ...rest) {
    requests.set(this, { method: String(method).toUpperCase(), url: absolute(String(url)) });
    return open.call(this, method, url, ...rest);
  };
  XMLHttpRequest.prototype.send = function(body) {
    const request = requests.get(this);
    if (request && request.method === "POST" && isGraphql(request.url)) {
      const postData = bodyText(body);
      this.addEventListener("loadend", () => {
        try {
          let text = null;
          if (this.responseType === "" || this.responseType === "text") text = this.responseText;
          else if (this.responseType === "json" && this.response != null) text = JSON.stringify(this.response);
          if (text != null) emit(request.url, this.status, this.getResponseHeader("content-type"), postData, text);
        } catch {
        }
      });
    }
    return send.call(this, body);
  };
  var pageFetch = window.fetch;
  window.fetch = async function(input, init) {
    const response = await pageFetch.call(this ?? window, input, init);
    try {
      const url = absolute(input instanceof Request ? input.url : String(input));
      const method = (init?.method ?? (input instanceof Request ? input.method : "GET")).toUpperCase();
      if (method === "POST" && isGraphql(url)) {
        const postData = bodyText(init?.body);
        response.clone().text().then((text) => emit(url, response.status, response.headers.get("content-type"), postData, text)).catch(() => void 0);
      }
    } catch {
    }
    return response;
  };
})();
