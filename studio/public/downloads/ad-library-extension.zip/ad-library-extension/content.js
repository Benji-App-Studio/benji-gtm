"use strict";
(() => {
  // supabase/functions/radar/engine/adlibrary.ts
  function trackingTool(host) {
    if (!host) return null;
    const h = host.toLowerCase();
    if (h.endsWith("appstack.link")) return "AppStack";
    if (h.endsWith("onelink.me") || h.includes("appsflyer")) return "AppsFlyer";
    if (h.endsWith("adj.st") || h.endsWith("adjust.com") || h.endsWith("go.link")) return "Adjust";
    if (h.endsWith("app.link") || h.endsWith("branch.io") || h.endsWith("bnc.lt")) return "Branch";
    if (h.endsWith("sng.link") || h.includes("singular")) return "Singular";
    if (h.endsWith("kochava.com")) return "Kochava";
    if (h.endsWith("apps.apple.com") || h.endsWith("itunes.apple.com")) return "App Store";
    if (h.endsWith("play.google.com")) return "Google Play";
    return null;
  }
  function libraryDetails(raw, advertiser) {
    const snap = pick(raw, "snapshot") ?? {};
    const imp = pick(raw, "impressionsWithIndex", "impressions_with_index");
    const impText = str(imp?.impressions_text ?? imp?.impressionsText);
    const impIndex = Number(imp?.impressions_index ?? imp?.impressionsIndex);
    const impressions = impText && Number.isFinite(impIndex) && impIndex >= 0 ? { text: impText, index: impIndex } : null;
    const posterName = str(pick(snap, "pageName", "page_name"));
    const posterId = str(pick(snap, "pageId", "page_id")) || null;
    const postedAs = posterName ? {
      name: posterName,
      pageId: posterId,
      profileUrl: str(pick(snap, "pageProfileUri", "page_profile_uri")) || null,
      picture: str(pick(snap, "pageProfilePictureUrl", "page_profile_picture_url")) || null,
      categories: list(pick(snap, "pageCategories", "page_categories")).map(str).filter(Boolean),
      likes: Number.isFinite(Number(pick(snap, "pageLikeCount", "page_like_count"))) ? Number(pick(snap, "pageLikeCount", "page_like_count")) : null
    } : null;
    const branded = pick(snap, "brandedContent", "branded_content") ?? null;
    const sponsorName = branded ? str(pick(branded, "pageName", "page_name")) : "";
    const sponsorId = branded ? str(pick(branded, "pageId", "page_id")) || null : null;
    const same = (id, name) => id && advertiser.pageId ? id === advertiser.pageId : name.toLowerCase() === advertiser.pageName.toLowerCase();
    let partner = null;
    if (branded && sponsorName) {
      partner = !same(sponsorId, sponsorName) ? { name: sponsorName, pageId: sponsorId, profileUrl: str(pick(branded, "pageProfileUri", "page_profile_uri")) || null } : postedAs && !same(postedAs.pageId, postedAs.name) ? { name: postedAs.name, pageId: postedAs.pageId, profileUrl: postedAs.profileUrl } : null;
    } else if (postedAs && !same(postedAs.pageId, postedAs.name)) {
      partner = { name: postedAs.name, pageId: postedAs.pageId, profileUrl: postedAs.profileUrl };
    }
    const link = str(pick(snap, "linkUrl", "link_url"));
    const linkHost = (() => {
      try {
        return link ? new URL(link).hostname.replace(/^www\./, "") : null;
      } catch {
        return null;
      }
    })();
    const categories = list(pick(raw, "categories")).map(str).filter((c) => c && c !== "UNKNOWN");
    return {
      impressions,
      lowImpressions: impressions?.index === 0,
      postedAs,
      partner,
      ctaType: str(pick(snap, "ctaType", "cta_type")) || null,
      landingDomain: str(pick(snap, "caption")).toLowerCase() || null,
      linkHost,
      tracking: trackingTool(linkHost),
      ageGated: str(pick(raw, "gatedType", "gated_type")) === "LOGGED_OUT",
      aiGenerated: pick(raw, "containsDigitalCreatedMedia", "contains_digital_created_media") === true,
      sensitive: pick(raw, "containsSensitiveContent", "contains_sensitive_content") === true,
      categories
    };
  }
  function daysRunning(ad, now = Date.now()) {
    if (!ad.startedAt) return null;
    const start = Date.parse(ad.startedAt);
    if (Number.isNaN(start)) return null;
    const end = ad.stoppedAt ? Date.parse(ad.stoppedAt) : now;
    return Math.max(1, Math.floor((end - start) / 864e5) + 1);
  }
  var str = (value) => (typeof value === "string" ? value : typeof value === "number" ? String(value) : "").trim();
  var first = (...values) => values.map(str).find(Boolean) ?? "";
  var list = (value) => Array.isArray(value) ? value : value == null ? [] : [value];
  function isoDate(value) {
    if (value == null || value === "") return null;
    if (typeof value === "number" || /^\d+$/.test(String(value))) {
      const n = Number(value);
      const ms = n < 1e12 ? n * 1e3 : n;
      const date2 = new Date(ms);
      return Number.isNaN(date2.getTime()) ? null : date2.toISOString();
    }
    const date = new Date(String(value));
    return Number.isNaN(date.getTime()) ? null : date.toISOString();
  }
  var tidy = (text2) => text2.replace(/\{\{[^}]+\}\}/g, "").replace(/\s+\n/g, "\n").trim();
  var PLACEMENTS = {
    facebook: "facebook",
    instagram: "instagram",
    audience_network: "audience_network",
    messenger: "messenger",
    threads: "threads",
    whatsapp: "whatsapp",
    tiktok: "tiktok"
  };
  var placementsOf = (value) => [...new Set(list(value).map((p) => PLACEMENTS[str(p).toLowerCase()]).filter(Boolean))];
  function mediaTypeOf(media, hint) {
    const h = hint.toLowerCase();
    if (h.includes("dco") || h.includes("dpa")) return "dco";
    if (h.includes("carousel") || h.includes("multi")) return "carousel";
    if (h.includes("video")) return "video";
    if (h.includes("image") || h.includes("meme")) return "image";
    if (media.some((m) => m.type === "video")) return "video";
    if (media.length > 1) return "carousel";
    if (media.length === 1) return "image";
    return h === "text" || h === "none" ? "text" : "unknown";
  }
  function adLibraryUrl(o) {
    const params = new URLSearchParams({
      active_status: o.activeOnly === false ? "all" : "active",
      ad_type: "all",
      country: (o.country ?? "ALL").toUpperCase(),
      media_type: o.mediaType ?? "all"
    });
    if (o.pageId) {
      params.set("search_type", "page");
      params.set("view_all_page_id", o.pageId);
    } else {
      params.set("search_type", "keyword_unordered");
      params.set("q", o.searchTerms ?? "");
    }
    return `https://www.facebook.com/ads/library/?${params}`;
  }
  var pick = (raw, ...keys) => keys.map((k) => raw?.[k]).find((v) => v != null && v !== "");
  function fromMetaLibrary(raw, o = {}) {
    const adId = str(pick(raw, "adArchiveID", "ad_archive_id", "adArchiveId", "adid", "id"));
    const activeSeconds = Number(pick(raw, "totalActiveTime", "total_active_time"));
    if (!adId) return null;
    const snap = pick(raw, "snapshot") ?? {};
    const cards = list(pick(snap, "cards"));
    const media = [];
    const addVideo = (v) => {
      const url = str(pick(v, "videoHdUrl", "video_hd_url", "videoSdUrl", "video_sd_url"));
      if (url) media.push({ type: "video", url, thumb: str(pick(v, "videoPreviewImageUrl", "video_preview_image_url")) || null });
    };
    const addImage = (i) => {
      const url = str(pick(i, "originalImageUrl", "original_image_url", "resizedImageUrl", "resized_image_url"));
      if (url) media.push({ type: "image", url });
    };
    list(pick(snap, "videos")).forEach((v) => addVideo(v));
    list(pick(snap, "images")).forEach((i) => addImage(i));
    cards.forEach((card) => {
      addVideo(card);
      addImage(card);
    });
    const bodyField = pick(snap, "body");
    const body = tidy(typeof bodyField === "string" ? bodyField : str(bodyField?.text ?? bodyField?.markup?.__html)) || tidy(first(cards[0]?.body));
    const stoppedAt = raw.isActive === true || raw.is_active === true ? null : isoDate(pick(raw, "endDate", "end_date"));
    const format = str(pick(snap, "displayFormat", "display_format"));
    const collation = Number(pick(raw, "collationCount", "collation_count") ?? 1);
    const pageId = str(pick(raw, "pageID", "page_id", "pageId")) || str(pick(snap, "pageId", "page_id")) || null;
    const pageName = first(pick(raw, "pageName", "page_name"), pick(snap, "pageName", "page_name")) || "Unknown advertiser";
    return {
      adId,
      network: "meta",
      source: o.source ?? "meta_apify",
      pageId,
      pageName,
      competitor: o.competitor ?? null,
      startedAt: isoDate(pick(raw, "startDate", "start_date", "startDateFormatted", "start_date_formatted")) ?? (activeSeconds > 0 ? new Date(Date.now() - activeSeconds * 1e3).toISOString() : null),
      stoppedAt,
      active: Boolean(pick(raw, "isActive", "is_active") ?? !stoppedAt),
      placements: placementsOf(pick(raw, "publisherPlatform", "publisher_platform", "publisherPlatforms", "publisher_platforms")),
      mediaType: mediaTypeOf(media, cards.length > 1 ? "carousel" : format),
      body,
      headline: tidy(first(pick(snap, "title"), cards[0]?.title)),
      description: tidy(first(pick(snap, "linkDescription", "link_description"), cards[0]?.linkDescription, cards[0]?.link_description)),
      cta: first(pick(snap, "ctaText", "cta_text"), cards[0]?.ctaText, cards[0]?.cta_text),
      linkUrl: first(pick(snap, "linkUrl", "link_url"), cards[0]?.linkUrl, cards[0]?.link_url) || null,
      media,
      thumb: media.find((m) => m.type === "image")?.url ?? media.find((m) => m.thumb)?.thumb ?? null,
      snapshotUrl: `https://www.facebook.com/ads/library/?id=${adId}`,
      countries: o.countries ?? list(pick(raw, "reachedCountries", "targeted_or_reached_countries")).map(str).filter(Boolean),
      languages: [],
      collationId: str(pick(raw, "collationID", "collation_id", "collationId")) || null,
      variants: Number.isFinite(collation) && collation > 0 ? collation : 1,
      reach: Number(pick(raw, "reachEstimate", "reach_estimate")) || null,
      library: libraryDetails(raw, { pageId, pageName })
    };
  }

  // scripts/meta-ad-library/src/parser.ts
  var libraryIdOf = (raw) => String(raw?.ad_archive_id ?? raw?.adArchiveID ?? "").trim();
  function parseNdjson(text2) {
    const body = text2.replace(/^\s*for\s*\(\s*;\s*;\s*\)\s*;/, "").trim();
    if (!body) return [];
    try {
      return [JSON.parse(body)];
    } catch {
    }
    const docs = [];
    for (const line of body.split(/\r?\n/)) {
      const trimmed = line.replace(/^\s*for\s*\(\s*;\s*;\s*\)\s*;/, "").trim();
      if (!trimmed) continue;
      try {
        docs.push(JSON.parse(trimmed));
      } catch {
      }
    }
    return docs;
  }
  function collect(value, key, out = []) {
    if (Array.isArray(value)) value.forEach((item) => collect(item, key, out));
    else if (value && typeof value === "object") {
      for (const [k, child] of Object.entries(value)) {
        if (k === key) out.push(child);
        else collect(child, key, out);
      }
    }
    return out;
  }
  var isAd = (value) => value && typeof value === "object" && !Array.isArray(value) && value.ad_archive_id != null && value.snapshot && typeof value.snapshot === "object";
  function collectAds(value, out = []) {
    if (Array.isArray(value)) value.forEach((item) => collectAds(item, out));
    else if (value && typeof value === "object") {
      if (isAd(value)) out.push(value);
      else Object.values(value).forEach((child) => collectAds(child, out));
    }
    return out;
  }
  var adsOfConnection = (conn) => (Array.isArray(conn?.edges) ? conn.edges : []).flatMap((edge) => {
    const node = edge?.node ?? edge;
    return Array.isArray(node?.collated_results) ? node.collated_results : [];
  });
  function findConnections(value) {
    const pages = collect(value, "search_results_connection").filter((c) => c && typeof c === "object").map((c) => ({
      count: c.count != null && Number.isFinite(Number(c.count)) ? Number(c.count) : null,
      endCursor: c.page_info?.end_cursor ?? null,
      hasNextPage: typeof c.page_info?.has_next_page === "boolean" ? c.page_info.has_next_page : null,
      ads: adsOfConnection(c)
    }));
    const known = new Set(pages.flatMap((p) => p.ads.map(libraryIdOf)));
    const loose = [];
    for (const ad of [...collect(value, "collated_results").filter(Array.isArray).flat(), ...collectAds(value)]) {
      const id = libraryIdOf(ad);
      if (!id || known.has(id)) continue;
      known.add(id);
      loose.push(ad);
    }
    if (loose.length) pages.push({ count: null, endCursor: null, hasNextPage: null, ads: loose, loose: true });
    return pages;
  }
  var pageKey = (page) => page.endCursor ? `cursor:${page.endCursor}` : `ids:${page.ads.map((a) => a?.ad_archive_id ?? "?").join(",")}`;
  var ResultsAccumulator = class {
    pages = [];
    keys = /* @__PURE__ */ new Set();
    ids = /* @__PURE__ */ new Set();
    ads = [];
    rank = 0;
    real = 0;
    lastCount = null;
    lastHasNext = null;
    /** Adds one record; returns the pages it added (repeats of known pages are skipped). */
    add(record) {
      const added = [];
      for (const page of findConnections(record.data)) {
        const key = pageKey(page);
        if (this.keys.has(key)) continue;
        this.keys.add(key);
        this.pages.push(page);
        added.push(page);
        if (!page.loose) this.real += 1;
        if (page.count != null) this.lastCount = page.count;
        if (!page.loose && page.hasNextPage != null) this.lastHasNext = page.hasNextPage;
        for (const raw of page.ads) {
          this.rank += 1;
          const id = libraryIdOf(raw);
          if (!id || this.ids.has(id)) continue;
          this.ids.add(id);
          this.ads.push({ rank: this.rank, raw });
        }
      }
      return added;
    }
    get result() {
      return {
        pages: this.pages,
        pagesLoaded: this.real || (this.pages.length ? 1 : 0),
        ads: this.ads,
        seen: this.rank,
        metaReportedTotal: this.lastCount,
        hasNextPage: this.lastHasNext
      };
    }
  };
  function extractResults(records) {
    const acc = new ResultsAccumulator();
    for (const record of records) acc.add(record);
    return acc.result;
  }

  // scripts/meta-ad-library/src/shared.ts
  var COOLDOWN_MS = 6 * 60 * 60 * 1e3;
  var MIN_GAP_MS = 30 * 60 * 1e3;
  var KNOWN_PAGES_TO_STOP = 2;
  var MAX_MEASURED_ADS = 40;
  function utcDay(value) {
    if (value == null || value === "") return null;
    const n = typeof value === "number" || /^\d+$/.test(String(value)) ? Number(value) : NaN;
    const date = Number.isFinite(n) ? new Date(n < 1e12 ? n * 1e3 : n) : new Date(String(value));
    return Number.isNaN(date.getTime()) ? null : date.toISOString().slice(0, 10);
  }
  var sleep = (ms) => new Promise((done) => setTimeout(done, ms));
  var between = (min, max, random = Math.random) => Math.round(min + random() * (max - min));
  function scrollPauseMs(random = Math.random) {
    return random() < 0.15 ? between(8e3, 12e3, random) : between(2500, 6e3, random);
  }
  var measureGapMs = (random = Math.random) => between(300, 800, random);
  var PERSONAL_KEYS = /* @__PURE__ */ new Set(["viewer", "actor", "ad_library_user"]);
  var SESSION_FIELDS = /* @__PURE__ */ new Set([
    "fb_dtsg",
    "fb_dtsg_ag",
    "lsd",
    "jazoest",
    "__user",
    "__a",
    "__req",
    "__hs",
    "__hsi",
    "__dyn",
    "__csr",
    "__rev",
    "__s",
    "__spin_r",
    "__spin_b",
    "__spin_t",
    "__comet_req",
    "__ccg",
    "__jssesw",
    "__aaid",
    "__hsdp",
    "__hblp",
    "__sjsp",
    "dpr",
    "av",
    "server_timestamps",
    "cookie",
    "cookies",
    "set-cookie",
    "authorization"
  ]);
  function sanitize(value) {
    if (Array.isArray(value)) return value.map((item) => sanitize(item));
    if (value && typeof value === "object") {
      const out = {};
      for (const [key, child] of Object.entries(value)) {
        if (PERSONAL_KEYS.has(key) || SESSION_FIELDS.has(key.toLowerCase())) continue;
        out[key] = sanitize(child);
      }
      return out;
    }
    return value;
  }

  // scripts/meta-ad-library/src/network.ts
  function requestMeta(postData) {
    const out = { friendlyName: null, docId: null, variables: null };
    if (!postData) return out;
    let form;
    try {
      form = new URLSearchParams(postData);
    } catch {
      return out;
    }
    out.friendlyName = form.get("fb_api_req_friendly_name");
    out.docId = form.get("doc_id");
    const variables = form.get("variables");
    if (variables) {
      try {
        out.variables = sanitize(JSON.parse(variables));
      } catch {
        out.variables = null;
      }
      if (out.variables && typeof out.variables === "object") {
        for (const key of Object.keys(out.variables)) if (SESSION_FIELDS.has(key.toLowerCase())) delete out.variables[key];
      }
    }
    return out;
  }
  var cleanUrl = (url) => {
    try {
      const u = new URL(url);
      return `${u.origin}${u.pathname}`;
    } catch {
      return url.split("?")[0];
    }
  };
  function buildRecord(o) {
    return {
      timestamp: o.timestamp ?? (/* @__PURE__ */ new Date()).toISOString(),
      url: cleanUrl(o.url),
      status: o.status,
      method: o.method,
      contentType: o.contentType,
      ...requestMeta(o.postData),
      data: parseNdjson(o.body).map((doc) => sanitize(doc))
    };
  }
  var RATE_LIMIT_CODE = 1675004;
  var BLOCK_TEXT = /rate limit|temporarily blocked|blocked from searching|too many requests|try again later|checkpoint|suspicious activity|you can't use this feature/i;
  var errorsOf = (doc) => Array.isArray(doc?.errors) ? doc.errors : doc?.error != null ? [doc] : [];
  var describe = (e) => [e?.code ?? e?.error, e?.message ?? e?.summary ?? e?.errorSummary, e?.description ?? e?.errorDescription].filter((v) => v != null && v !== "").join(" ");
  function classifyGraphql(status, docs, adsParsed) {
    const errors = docs.flatMap(errorsOf);
    for (const e of errors) {
      const code = Number(e?.code ?? e?.error);
      const text2 = describe(e);
      if (code === RATE_LIMIT_CODE || BLOCK_TEXT.test(text2)) return { block: { reason: `GraphQL error: ${text2 || code}` } };
    }
    const coded = errors.filter((e) => e?.code != null || typeof e?.error === "number");
    if (coded.length) {
      const text2 = coded.map(describe).join("; ");
      return adsParsed > 0 ? { warning: `GraphQL returned an error next to ${adsParsed} ads (${text2}); continuing.` } : { block: { reason: `GraphQL error without ads: ${text2}` } };
    }
    if (status === 429) return { block: { reason: "HTTP 429 (too many requests) from /api/graphql/" } };
    if (status === 403) {
      return adsParsed > 0 ? { warning: "HTTP 403 from /api/graphql/ but the body still carried ads; continuing." } : { block: { reason: "HTTP 403 from /api/graphql/ with no ads in the body" } };
    }
    return {};
  }
  function blockedUrl(url) {
    let u;
    try {
      u = new URL(url);
    } catch {
      return null;
    }
    if (u.protocol === "about:" || u.protocol === "chrome-error:") return null;
    if (!/(^|\.)facebook\.com$/i.test(u.hostname)) return { reason: `Redirected off facebook.com (${u.hostname})` };
    if (/\/checkpoint\//i.test(u.pathname) || /^\/login/i.test(u.pathname) || /\/login\.php/i.test(u.pathname)) return { reason: `Redirected to ${u.pathname}` };
    return null;
  }

  // scripts/meta-ad-library/src/normalizer.ts
  var SCHEMA = "radar.meta-ad-library/v1";
  var text = (value) => {
    const s = typeof value === "string" ? value : typeof value === "number" ? String(value) : "";
    return s.trim() || null;
  };
  var firstText = (...values) => values.map(text).find((v) => v != null) ?? null;
  var arr = (value) => Array.isArray(value) ? value : [];
  var bodyText = (body) => typeof body === "string" ? text(body) : text(body?.text ?? body?.markup?.__html);
  function mediaOf(snapshot) {
    const media = [];
    const seen = /* @__PURE__ */ new Set();
    const push = (item) => {
      if (!seen.has(item.url)) {
        seen.add(item.url);
        media.push(item);
      }
    };
    const video = (v) => {
      const url = firstText(v?.video_hd_url, v?.video_sd_url, v?.watermarked_video_hd_url, v?.watermarked_video_sd_url);
      if (!url) return false;
      const thumb = text(v?.video_preview_image_url);
      push(thumb ? { type: "video", url, thumbnail_url: thumb } : { type: "video", url });
      return true;
    };
    const image = (i) => {
      const url = firstText(i?.original_image_url, i?.resized_image_url, i?.watermarked_resized_image_url);
      if (url) push({ type: "image", url });
    };
    for (const card of arr(snapshot?.cards)) if (!video(card)) image(card);
    arr(snapshot?.videos).forEach(video);
    arr(snapshot?.images).forEach(image);
    arr(snapshot?.extra_videos).forEach(video);
    arr(snapshot?.extra_images).forEach(image);
    return media;
  }
  var PLACEHOLDER = /\{\{\s*product\./i;
  function creativeTypeOf(displayFormat, media, texts) {
    const format = (displayFormat ?? "").toUpperCase();
    if (format === "DPA" || texts.some((t) => t && PLACEHOLDER.test(t))) return { type: "OTHER", displayFormat: "DPA" };
    if (format === "DCO") return { type: "DCO", displayFormat };
    if (format === "CAROUSEL") return { type: "CAROUSEL", displayFormat };
    if (media.some((m) => m.type === "video") || format === "VIDEO") return { type: "VIDEO", displayFormat };
    if (media.some((m) => m.type === "image") || format === "IMAGE") return { type: "IMAGE", displayFormat };
    return { type: "OTHER", displayFormat };
  }
  function normalizeAd(raw, rank, now = Date.now()) {
    const libraryId = libraryIdOf(raw);
    const mapped = fromMetaLibrary(raw);
    if (!libraryId || !mapped) return null;
    const snap = raw.snapshot ?? {};
    const card = arr(snap.cards)[0] ?? {};
    const media = mediaOf(snap);
    const primary = firstText(bodyText(snap.body), bodyText(card.body));
    const headline = firstText(snap.title, card.title);
    const description = firstText(snap.link_description, card.link_description);
    const kind = creativeTypeOf(text(snap.display_format), media, [primary, headline, description]);
    const active = raw.is_active === true || raw.is_active == null && mapped.active;
    const collation = Number(raw.collation_count);
    return {
      library_id: libraryId,
      collation_id: text(raw.collation_id),
      collation_count: raw.collation_count != null && Number.isFinite(collation) ? collation : null,
      impressions_rank: rank,
      status: active ? "ACTIVE" : "INACTIVE",
      start_date: utcDay(raw.start_date),
      end_date: active ? null : utcDay(raw.end_date),
      days_running: daysRunning({ startedAt: mapped.startedAt, stoppedAt: active ? null : mapped.stoppedAt }, now),
      platforms: [...new Set(arr(raw.publisher_platform).map((p) => String(p).toUpperCase()))],
      creative_type: kind.type,
      display_format: kind.displayFormat,
      primary_text: primary,
      headline,
      description,
      cta: firstText(snap.cta_text, card.cta_text),
      cta_type: firstText(snap.cta_type, card.cta_type),
      destination_url: firstText(snap.link_url, card.link_url),
      creative: { card_count: arr(snap.cards).length, media },
      raw: sanitize(raw)
    };
  }
  var urlParam = (url, key) => {
    try {
      return new URL(url).searchParams.get(key);
    } catch {
      return null;
    }
  };
  function advertiserOf(ads, info) {
    const fromUrl = urlParam(info.input_url, "view_all_page_id");
    const counts = /* @__PURE__ */ new Map();
    for (const ad of ads) {
      const id = text(ad.raw.page_id ?? ad.raw.snapshot?.page_id);
      if (id) counts.set(id, (counts.get(id) ?? 0) + 1);
    }
    const pageId = fromUrl ?? [...counts.entries()].sort((a, b) => b[1] - a[1])[0]?.[0] ?? null;
    const sample = ads.find((ad) => text(ad.raw.page_id ?? ad.raw.snapshot?.page_id) === pageId)?.raw;
    const snap = sample?.snapshot ?? {};
    const advertiser = {
      page_id: pageId,
      page_name: firstText(sample?.page_name, snap.page_name),
      page_url: text(snap.page_profile_uri),
      ad_library_url: pageId ? adLibraryUrl({ pageId, country: info.country ?? urlParam(info.input_url, "country") ?? "ALL", activeOnly: info.active_only ?? urlParam(info.input_url, "active_status") !== "all" }) : info.input_url
    };
    const likes = Number(snap.page_like_count);
    if (snap.page_like_count != null && Number.isFinite(likes)) advertiser.page_like_count = likes;
    const picture = text(snap.page_profile_picture_url);
    if (picture) advertiser.page_profile_picture_url = picture;
    return advertiser;
  }
  function buildOutput(parsed, info, now = Date.now()) {
    const ads = parsed.ads.map(({ rank, raw }) => normalizeAd(raw, rank, now)).filter((a) => a != null).sort((a, b) => a.impressions_rank - b.impressions_rank);
    const creativeTypes = { video: 0, image: 0, carousel: 0, dco: 0, other: 0 };
    const platforms = {};
    for (const ad of ads) {
      creativeTypes[ad.creative_type.toLowerCase()] += 1;
      for (const p of ad.platforms) platforms[p] = (platforms[p] ?? 0) + 1;
    }
    return {
      schema: SCHEMA,
      scraped_at: info.scraped_at,
      input_url: info.input_url,
      complete: info.complete,
      stopped_reason: info.stopped_reason,
      pages_loaded: parsed.pagesLoaded,
      advertiser: advertiserOf(ads, info),
      summary: {
        total_ads: ads.length,
        active_ads: ads.filter((a) => a.status === "ACTIVE").length,
        meta_reported_total: parsed.metaReportedTotal,
        creative_types: creativeTypes,
        platforms
      },
      ads
    };
  }
  function nearestPlacement(width, height) {
    if (!(width > 0 && height > 0)) return null;
    const ratio = width / height;
    if (ratio >= 1.6) return "landscape";
    const targets = [[9 / 16, "stories_reels"], [3 / 4, "feed_vertical"], [4 / 5, "feed_vertical"], [1, "square"], [16 / 9, "landscape"]];
    return targets.reduce((best, t) => Math.abs(Math.log(ratio / t[0])) < Math.abs(Math.log(ratio / best[0])) ? t : best)[1];
  }
  function mediaToMeasure(output, max) {
    const items = [];
    for (const ad of output.ads.slice(0, max)) {
      const video = ad.creative.media.find((m) => m.type === "video");
      const image = ad.creative.media.find((m) => m.type === "image");
      if (image) items.push({ key: `${ad.library_id}#image`, type: "image", url: image.url });
      if (video) items.push({ key: `${ad.library_id}#video`, type: "video", url: video.url });
    }
    return items;
  }
  function applyMeasurements(output, sizes) {
    let applied = 0;
    for (const ad of output.ads) {
      for (const type of ["image", "video"]) {
        const size = sizes.get(`${ad.library_id}#${type}`);
        const item = ad.creative.media.find((m) => m.type === type);
        if (!size || !item || !size.width || !size.height) continue;
        item.width = size.width;
        item.height = size.height;
        if (size.durationSec != null) item.duration_sec = size.durationSec;
        item.aspect = Math.round(size.width / size.height * 1e4) / 1e4;
        applied += 1;
      }
      const basis = ad.creative.media.find((m) => m.type === "video" && m.width) ?? ad.creative.media.find((m) => m.type === "image" && m.width);
      const placement = basis?.width && basis.height ? nearestPlacement(basis.width, basis.height) : null;
      if (placement) ad.nearest_placement = placement;
    }
    return applied;
  }

  // scripts/meta-ad-library/src/rules.ts
  var FIRST_RESULTS_MS = 2e4;
  var NEXT_RESULTS_MS = 2e4;
  var EMPTY_SCROLLS_TO_STOP = 3;
  var CONSENT_WAIT_MS = 5 * 6e4;
  function collectKey(value, key, out = []) {
    if (Array.isArray(value)) value.forEach((v) => collectKey(v, key, out));
    else if (value && typeof value === "object") {
      for (const [k, child] of Object.entries(value)) {
        if (k === key) out.push(child);
        else collectKey(child, key, out);
      }
    }
    return out;
  }
  function extractEmbeddedResults(html) {
    const docs = [];
    const blocks = html.matchAll(/<script\b[^>]*type="application\/json"[^>]*>([\s\S]*?)<\/script>/gi);
    for (const [, body] of blocks) {
      if (!body.includes("search_results_connection") && !body.includes("ad_archive_id")) continue;
      for (const json of parseNdjson(body)) {
        const connections = collectKey(json, "search_results_connection");
        for (const connection of connections) {
          docs.push(sanitize({ data: { ad_library_main: { search_results_connection: connection } } }));
        }
        if (!connections.length) {
          const ads = findConnections(json).flatMap((p) => p.ads);
          if (ads.length) docs.push(sanitize({ ads }));
        }
      }
    }
    return docs;
  }
  var BLOCK_PAGE_TEXT = /you[’']re temporarily blocked|blocked from searching or viewing the ad library/i;
  function caughtUp(state, known, pages = KNOWN_PAGES_TO_STOP) {
    if (!known?.size) return false;
    const real = state.pages.filter((p) => !p.loose);
    if (real.length < pages) return false;
    return real.slice(-pages).every((p) => p.ads.length > 0 && p.ads.every((ad) => known.has(libraryIdOf(ad))));
  }
  function silentEmptyPage(state) {
    const real = state.pages.filter((p) => !p.loose);
    if (real.length < 2) return false;
    const [before, last] = real.slice(-2);
    return before.hasNextPage === true && last.ads.length === 0;
  }

  // chrome-extension/src/protocol.ts
  var DEFAULT_DASHBOARD_URL = "http://localhost:3000";
  var DASHBOARD_KEY = "dashboardUrl";
  function cleanDashboardUrl(value) {
    const text2 = value.trim();
    if (!text2) return null;
    const local = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?(\/|$)/i.test(text2);
    try {
      const url = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(text2) ? text2 : `${local ? "http" : "https"}://${text2}`);
      return (url.protocol === "http:" || url.protocol === "https:") && url.hostname ? url.origin : null;
    } catch {
      return null;
    }
  }
  var dashboardAppUrl = (base) => `${base.replace(/\/+$/, "")}/app`;
  async function loadDashboardUrl() {
    try {
      const stored = (await chrome.storage.local.get(DASHBOARD_KEY))[DASHBOARD_KEY];
      return typeof stored === "string" && cleanDashboardUrl(stored) || DEFAULT_DASHBOARD_URL;
    } catch {
      return DEFAULT_DASHBOARD_URL;
    }
  }
  var DOWNLOAD_FOLDER = "Ad Library";
  var ADS_PER_PAGE = 28;
  var pagesFor = (total) => Math.max(1, Math.ceil(total / ADS_PER_PAGE));
  var FILE_PORT = "ad-library:file";
  var FILE_CHUNK_CHARS = 4e6;
  var HOOK_EVENT = "ad-library:graphql";

  // chrome-extension/src/ui-common.ts
  function logoSvg(size, key = "a") {
    return `<svg width="${size}" height="${size}" viewBox="0 0 28 28" aria-hidden="true" focusable="false"><defs><linearGradient id="rl-g-${key}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f59e4b"/><stop offset="1" stop-color="#e0621a"/></linearGradient></defs><rect width="28" height="28" rx="8" fill="url(#rl-g-${key})"/><path d="M8 .5h12a7.5 7.5 0 0 1 7.5 7.5" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="1"/><circle cx="14" cy="14" r="6" fill="none" stroke="#fff" stroke-opacity=".85" stroke-width="2"/><circle cx="14" cy="14" r="3" fill="#fff"/></svg>`;
  }
  var ACTIVE_PHASES = ["opening", "consent", "collecting", "paused", "measuring", "saving"];
  var isActive = (run2) => !!run2 && ACTIVE_PHASES.includes(run2.phase);
  var PHASE_LABEL = {
    opening: "Opening",
    consent: "Cookie choice",
    collecting: "Collecting",
    paused: "Paused",
    measuring: "Measuring",
    saving: "Saving",
    done: "Done",
    blocked: "Blocked",
    failed: "Failed"
  };
  function progressFraction(run2) {
    const p = run2.progress;
    if (run2.phase === "measuring" && p.toMeasure) return clamp01((p.measured ?? 0) / p.toMeasure);
    if (run2.phase === "saving" || run2.phase === "done") return 1;
    return p.maxPages > 0 ? clamp01(p.pagesLoaded / p.maxPages) : 0;
  }
  var clamp01 = (n) => Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
  function countdown(nextScrollAt, now = Date.now()) {
    if (nextScrollAt == null) return null;
    const s = (nextScrollAt - now) / 1e3;
    if (s <= 0) return null;
    return s < 10 ? `${s.toFixed(1)} s` : `${Math.ceil(s)} s`;
  }
  var fmt = (n) => n.toLocaleString("en-US");
  var plural = (n, one, many = `${one}s`) => `${fmt(n)} ${n === 1 ? one : many}`;

  // chrome-extension/src/widget.ts
  var CSS = `
:host { all: initial; }
* { box-sizing: border-box; margin: 0; padding: 0; }
.root {
  --card: #f8f8f8; --raised: #fff; --control: #ebebeb; --ink: #0a0a0a; --label: #525252; --muted: #777;
  --faint: #8e8e8e; --primary: #2b2b2d; --on-ink: #fff; --line: #e6e6e6; --accent: #1f52e0;
  --win: #18a832; --warn: #de1381; --warn-soft: #fae4f0; --caution: #e47218; --caution-soft: #fdecd6; --caution-ink: #8a541e;
  --pop: 0 24px 60px -12px rgb(0 0 0 / .28), 0 2px 8px rgb(0 0 0 / .06);
  position: fixed; right: 16px; bottom: 16px; z-index: 2147483647;
  font: 13px/18px Inter, ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif;
  color: var(--ink); -webkit-font-smoothing: antialiased; text-align: left;
  pointer-events: auto; contain: layout style;
}
@media (prefers-color-scheme: dark) {
  .root {
    --card: #161618; --raised: #2a2a2e; --control: #1d1d20; --ink: #f4f4f5; --label: #c4c4ca; --muted: #9a9aa1;
    --faint: #74747c; --primary: #f4f4f5; --on-ink: #0e0e10; --line: #28282c; --accent: #5b85ff;
    --win: #3fcf5c; --warn: #ff4fa8; --warn-soft: rgb(255 79 168 / .14); --caution: #ff9447;
    --caution-soft: rgb(255 148 71 / .14); --caution-ink: #ffc08f;
    --pop: 0 24px 60px -12px rgb(0 0 0 / .7), 0 0 0 1px rgb(255 255 255 / .06);
  }
}
button { font: inherit; color: inherit; background: none; border: 0; cursor: pointer; }
a { color: var(--accent); text-decoration: none; font-weight: 500; }
a:hover { text-decoration: underline; }
svg { display: block; flex: none; }

.card {
  width: 300px; padding: 12px; display: flex; flex-direction: column; gap: 10px;
  background: var(--card); border: 1px solid var(--line); border-radius: 14px; box-shadow: var(--pop);
}
.head { display: flex; align-items: center; gap: 8px; height: 22px; }
.name { font-weight: 600; font-size: 13px; letter-spacing: -.01em; }
.pill { display: inline-flex; align-items: center; gap: 5px; height: 20px; padding: 0 7px; border-radius: 999px;
  border: 1px solid var(--line); background: var(--raised); font-size: 11px; font-weight: 500; white-space: nowrap; }
.pill i { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); }
.pill.run i { animation: pulse 1.4s ease-in-out infinite; }
.pill.caution i { background: var(--caution); }
.pill.win i { background: var(--win); }
.pill.warn i { background: var(--warn); }
@keyframes pulse { 50% { opacity: .35; } }
.icon-btn { margin-left: auto; width: 22px; height: 22px; display: grid; place-items: center; border-radius: 6px; color: var(--muted); }
.icon-btn:hover { background: color-mix(in srgb, var(--ink) 6%, transparent); color: var(--ink); }

.status { font-size: 12.5px; line-height: 17px; }
.bar { height: 4px; border-radius: 999px; background: var(--control); overflow: hidden; }
.bar i { display: block; height: 100%; width: 0; border-radius: inherit; background: var(--accent); transition: width .4s ease; }
.meta { display: flex; justify-content: space-between; gap: 8px; font-size: 11.5px; line-height: 16px; color: var(--muted); font-variant-numeric: tabular-nums; }
.meta b { color: var(--ink); font-weight: 500; }
.note { font-size: 12px; line-height: 16px; padding: 8px 10px; border-radius: 10px; }
.note.caution { background: var(--caution-soft); color: var(--caution-ink); }
.note.warn { background: var(--warn-soft); color: var(--ink); }
.note.warn b { color: var(--warn); font-weight: 600; display: block; margin-bottom: 2px; }
.big { font-size: 15px; line-height: 20px; font-weight: 500; letter-spacing: -.01em; font-variant-numeric: tabular-nums; }
.sub { font-size: 11.5px; line-height: 16px; color: var(--muted); margin-top: 2px; }
.sub.file { font-family: ui-monospace, SFMono-Regular, Menlo, monospace; font-size: 11px; white-space: nowrap; overflow: hidden; text-overflow: ellipsis; }
.actions { display: flex; align-items: center; gap: 8px; }
.actions a { margin-left: auto; font-size: 12.5px; }
.btn { display: inline-flex; align-items: center; justify-content: center; height: 28px; padding: 0 10px; border-radius: 8px;
  font-size: 12.5px; font-weight: 500; white-space: nowrap; }
.btn.primary { background: var(--primary); color: var(--on-ink); }
.btn.primary:hover { background: color-mix(in srgb, var(--primary) 88%, transparent); }
.btn.secondary { background: var(--raised); border: 1px solid var(--line); }
.btn.secondary:hover { border-color: color-mix(in srgb, var(--ink) 20%, transparent); }
.btn:disabled { opacity: .5; pointer-events: none; }
.btn:focus-visible, .icon-btn:focus-visible, .chip:focus-visible { outline: 2px solid var(--accent); outline-offset: 2px; }

.chip { display: inline-flex; align-items: center; gap: 7px; height: 32px; padding: 0 12px 0 6px; border-radius: 999px;
  background: var(--card); border: 1px solid var(--line); box-shadow: var(--pop); font-size: 12.5px; font-weight: 500;
  font-variant-numeric: tabular-nums; white-space: nowrap; }
.chip .dot { width: 6px; height: 6px; border-radius: 50%; background: var(--accent); }
.chip .dot.caution { background: var(--caution); } .chip .dot.win { background: var(--win); } .chip .dot.warn { background: var(--warn); }
.hidden { display: none !important; }

@media (prefers-reduced-motion: reduce) { * { transition: none !important; animation: none !important; } }
`;
  var CHEVRON_DOWN = `<svg width="14" height="14" viewBox="0 0 16 16" fill="none" stroke="currentColor" stroke-width="1.6" stroke-linecap="round" stroke-linejoin="round" aria-hidden="true"><path d="M4 6l4 4 4-4"/></svg>`;
  var toneOf = (run2) => run2.phase === "paused" || run2.phase === "consent" ? "caution" : run2.phase === "done" ? "win" : run2.phase === "blocked" || run2.phase === "failed" ? "warn" : "run";
  function mountWidget() {
    const host = document.createElement("ad-library-collector");
    host.style.cssText = "all:initial;position:fixed;width:0;height:0;top:0;left:0;z-index:2147483647;pointer-events:none;";
    const shadow = host.attachShadow({ mode: "closed" });
    shadow.innerHTML = `<style>${CSS}</style><div class="root" part="root">
    <div class="card" data-el="card">
      <div class="head">
        ${logoSvg(20, "w1")}
        <span class="name">Ad Library</span>
        <span class="pill run" data-el="pill"><i></i><span data-el="phase">Starting</span></span>
        <button class="icon-btn" data-el="collapse" type="button" aria-label="Collapse" title="Collapse">${CHEVRON_DOWN}</button>
      </div>
      <p class="status" data-el="status">Starting\u2026</p>
      <div data-el="running">
        <div class="bar" data-el="bar"><i data-el="fill"></i></div>
        <div class="meta" style="margin-top:8px"><span data-el="stats"></span><span data-el="next"></span></div>
      </div>
      <p class="note caution hidden" data-el="note"></p>
      <div class="hidden" data-el="done">
        <p class="big" data-el="saved"></p>
        <p class="sub file" data-el="file"></p>
        <p class="sub" data-el="diff"></p>
      </div>
      <p class="note warn hidden" data-el="error"><b data-el="error-title"></b><span data-el="error-text"></span></p>
      <div class="actions" data-el="actions">
        <button class="btn primary" type="button" data-el="stop">Stop and save</button>
        <button class="btn primary hidden" type="button" data-el="show">Show in Finder</button>
        <a href="${dashboardAppUrl(DEFAULT_DASHBOARD_URL)}" target="_blank" rel="noopener" class="hidden" data-el="dashboard">Open your dashboard</a>
      </div>
    </div>
    <button class="chip hidden" type="button" data-el="chip" aria-label="Expand the collector panel">${logoSvg(20, "w2")}<span class="dot" data-el="chip-dot"></span><span data-el="chip-text">Ad Library</span></button>
  </div>`;
    const $ = (name) => shadow.querySelector(`[data-el="${name}"]`);
    const el = {
      card: $("card"),
      pill: $("pill"),
      phase: $("phase"),
      collapse: $("collapse"),
      status: $("status"),
      running: $("running"),
      fill: $("fill"),
      stats: $("stats"),
      next: $("next"),
      note: $("note"),
      done: $("done"),
      saved: $("saved"),
      file: $("file"),
      diff: $("diff"),
      error: $("error"),
      errorTitle: $("error-title"),
      errorText: $("error-text"),
      actions: $("actions"),
      stop: $("stop"),
      show: $("show"),
      dashboard: $("dashboard"),
      chip: $("chip"),
      chipDot: $("chip-dot"),
      chipText: $("chip-text")
    };
    const linkDashboard = () => void loadDashboardUrl().then((url) => {
      el.dashboard.href = dashboardAppUrl(url);
    });
    linkDashboard();
    try {
      chrome.storage.onChanged.addListener((_changes, area) => {
        if (area === "local") linkDashboard();
      });
    } catch {
    }
    let run2 = null;
    let collapsed = false;
    let stopCbs = [];
    let showCbs = [];
    let timer;
    const show = (node, on) => node.classList.toggle("hidden", !on);
    const setText = (node, text2) => {
      if (node.textContent !== text2) node.textContent = text2;
    };
    function setCollapsed(next) {
      collapsed = next;
      show(el.card, !collapsed);
      show(el.chip, collapsed);
      if (!collapsed) el.collapse.focus({ preventScroll: true });
      syncTimer();
    }
    el.collapse.addEventListener("click", () => setCollapsed(true));
    el.chip.addEventListener("click", () => setCollapsed(false));
    el.stop.addEventListener("click", () => {
      el.stop.disabled = true;
      setText(el.stop, "Stopping\u2026");
      for (const cb of stopCbs) cb();
    });
    el.show.addEventListener("click", () => {
      for (const cb of showCbs) cb();
    });
    function tickNext() {
      if (!run2) return;
      if (run2.phase === "collecting") {
        const left = countdown(run2.progress.nextScrollAt);
        setText(el.next, left ? `next scroll ${left}` : "");
      } else if (run2.phase === "measuring") {
        setText(el.next, `media ${run2.progress.measured ?? 0}/${run2.progress.toMeasure ?? 0}`);
      } else setText(el.next, "");
    }
    function syncTimer() {
      const want = !!run2 && run2.phase === "collecting" && !collapsed && document.visibilityState === "visible";
      if (want && timer == null) timer = window.setInterval(tickNext, 250);
      if (!want && timer != null) {
        clearInterval(timer);
        timer = void 0;
      }
    }
    const onVisibility = () => syncTimer();
    document.addEventListener("visibilitychange", onVisibility);
    function update(next) {
      const phaseChanged = run2?.phase !== next.phase;
      run2 = next;
      const tone = toneOf(next);
      const active = isActive(next);
      const p = next.progress;
      el.pill.className = `pill ${tone}`;
      setText(el.phase, PHASE_LABEL[next.phase]);
      setText(el.status, next.status || PHASE_LABEL[next.phase]);
      show(el.running, active);
      if (active) {
        el.fill.style.width = `${(progressFraction(next) * 100).toFixed(1)}%`;
        const total = p.metaTotal != null ? ` of ${fmt(p.metaTotal)}` : "";
        el.stats.innerHTML = `<b>${fmt(p.ads)}</b> ads${total} \xB7 page <b>${p.pagesLoaded}</b>${p.toEnd ? p.maxPages ? `/~${p.maxPages}` : "" : `/${p.maxPages}`}`;
        tickNext();
      }
      const note = next.phase === "paused" ? "Paused: this window is minimized or covered. Keep it in view; you can work in other windows." : next.phase === "consent" ? "Choose a cookie option to continue." : "";
      setText(el.note, note);
      show(el.note, !!note);
      const s = next.summary;
      show(el.done, !!s);
      if (s) {
        setText(el.saved, `${plural(s.totalAds, "ad")} saved to Downloads/${DOWNLOAD_FOLDER}`);
        setText(el.file, s.fileName);
        setText(el.diff, s.diff ? `${fmt(s.diff.added)} new \xB7 ${fmt(s.diff.gone)} gone since last run` : "First run on this page");
        el.file.title = s.fileName;
      }
      const bad = next.phase === "blocked" || next.phase === "failed";
      show(el.status, active || !s && !bad);
      show(el.error, bad);
      if (bad) {
        setText(el.errorTitle, next.phase === "blocked" ? "Meta limited this connection" : "The run didn't finish");
        const until = next.cooldownUntil ? ` Next run possible at ${new Date(next.cooldownUntil).toLocaleTimeString([], { hour: "numeric", minute: "2-digit" })}.` : "";
        setText(el.errorText, `${next.error ?? ""}${until}`.trim());
      }
      show(el.stop, active);
      if (phaseChanged || !active) {
        el.stop.disabled = next.phase === "saving";
        setText(el.stop, next.phase === "saving" ? "Saving\u2026" : "Stop and save");
      }
      show(el.show, !!s);
      el.show.disabled = !s || s.downloadId == null;
      show(el.dashboard, !active);
      show(el.actions, active || !!s || bad);
      el.chipDot.className = `dot ${tone === "run" ? "" : tone}`;
      setText(el.chipText, s ? `${fmt(s.totalAds)} ads saved` : active ? `${fmt(p.ads)} ads \xB7 ${p.pagesLoaded}${p.toEnd ? p.maxPages ? `/~${p.maxPages}` : "" : `/${p.maxPages}`}` : PHASE_LABEL[next.phase]);
      if (collapsed && phaseChanged && (tone === "caution" || tone === "warn" || next.phase === "done")) setCollapsed(false);
      syncTimer();
    }
    (document.documentElement || document.body).appendChild(host);
    return {
      update,
      onStop(cb) {
        stopCbs.push(cb);
      },
      onShowFile(cb) {
        showCbs.push(cb);
      },
      destroy() {
        if (timer != null) clearInterval(timer);
        timer = void 0;
        document.removeEventListener("visibilitychange", onVisibility);
        stopCbs = [];
        showCbs = [];
        host.remove();
      }
    };
  }

  // chrome-extension/src/content.ts
  var early = [];
  var onCaptured = null;
  document.addEventListener(HOOK_EVENT, (event) => {
    let payload;
    try {
      payload = JSON.parse(String(event.detail));
    } catch {
      return;
    }
    const record = {
      ...buildRecord({ url: payload.url, status: payload.status, method: "POST", contentType: payload.contentType, postData: null, body: payload.body, timestamp: payload.at }),
      friendlyName: payload.friendlyName,
      docId: payload.docId,
      variables: payload.variables == null ? null : sanitize(payload.variables)
    };
    const pages = findConnections(record.data);
    const ads = pages.reduce((n, p) => n + p.ads.length, 0);
    const verdict = classifyGraphql(record.status, record.data, ads);
    const item = { record, block: verdict.block, warning: verdict.warning, results: pages.length > 0 && !verdict.block };
    if (onCaptured) onCaptured(item);
    else if (early.length < 200) early.push(item);
  });
  var send = (message) => chrome.runtime.sendMessage(message).catch(() => void 0);
  async function hello() {
    try {
      const reply = await chrome.runtime.sendMessage({ type: "hello", url: location.href });
      return reply?.run ?? null;
    } catch {
      return null;
    }
  }
  var visible = (el) => {
    if (!(el instanceof HTMLElement)) return false;
    const rect = el.getBoundingClientRect();
    return rect.width > 0 && rect.height > 0 && getComputedStyle(el).visibility !== "hidden";
  };
  function pageBlock() {
    const fromUrl = blockedUrl(location.href);
    if (fromUrl) return fromUrl;
    const text2 = document.body?.innerText ?? "";
    const notice = text2.match(BLOCK_PAGE_TEXT);
    if (notice) return { reason: `Page shows: "${notice[0]}"` };
    if (visible(document.querySelector('[role="dialog"] input[name="pass"]'))) return { reason: "A login wall covered the page" };
    return null;
  }
  var COOKIE_CHOICES = /allow all cookies|accept all cookies|allow essential and optional cookies|decline optional cookies|only allow essential cookies|reject optional cookies/i;
  var PRIVATE_CHOICE = /decline optional cookies|only allow essential cookies|allow essential cookies only|reject optional cookies/i;
  var label = (el) => `${el.getAttribute("aria-label") ?? ""} ${el.innerText ?? ""}`.trim();
  function consentDialog() {
    for (const dialog of document.querySelectorAll('[role="dialog"], [role="alertdialog"]')) {
      if (!visible(dialog)) continue;
      const buttons = [...dialog.querySelectorAll('button, [role="button"]')].filter(visible);
      if (!buttons.some((b) => COOKIE_CHOICES.test(label(b)))) continue;
      return { dialog, privateChoice: buttons.find((b) => PRIVATE_CHOICE.test(label(b))) ?? null };
    }
    return null;
  }
  var cardsOnScreen = () => ((document.body?.innerText ?? "").match(/Library ID/gi) ?? []).length;
  async function scrollDown() {
    const remaining = document.documentElement.scrollHeight - window.scrollY - window.innerHeight;
    let moved = 0;
    for (let step = 0; step < 12 && moved < remaining + 400; step += 1) {
      const delta = 600 + Math.round(Math.random() * 500);
      window.scrollBy({ top: delta, behavior: "auto" });
      moved += delta;
      await sleep(150 + Math.round(Math.random() * 250));
    }
  }
  function embeddedResults() {
    const html = [...document.querySelectorAll('script[type="application/json"]')].map((s) => s.textContent ?? "").filter((t) => t.includes("search_results_connection") || t.includes("ad_archive_id")).map((t) => `<script type="application/json">${t}<\/script>`).join("\n");
    return extractEmbeddedResults(html);
  }
  function pageInfo() {
    const state = extractResults([{ data: embeddedResults() }]);
    let total = state.metaReportedTotal;
    if (total == null) {
      const shown = (document.body?.innerText ?? "").match(/~?\s*([\d.,]+)\s*(K)?\s+results?\b/i);
      if (shown) total = Math.round(Number(shown[1].replace(/,/g, "")) * (shown[2] ? 1e3 : 1)) || null;
    }
    const first2 = state.ads[0]?.raw;
    return { total, pageName: first2?.page_name ?? first2?.snapshot?.page_name ?? null };
  }
  chrome.runtime.onMessage.addListener((message, _sender, reply) => {
    if (message?.type !== "page-info") return;
    const answer = () => {
      try {
        reply(pageInfo());
      } catch {
        reply({ total: null, pageName: null });
      }
    };
    if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", answer, { once: true });
    else answer();
    return true;
  });
  function measure(item, timeoutMs = 15e3) {
    return new Promise((resolve) => {
      let settled = false;
      const done = (value, cleanup2) => {
        if (settled) return;
        settled = true;
        clearTimeout(timer);
        cleanup2();
        resolve(value);
      };
      let cleanup = () => void 0;
      const timer = setTimeout(() => done(null, cleanup), timeoutMs);
      if (item.type === "image") {
        const img = new Image();
        cleanup = () => {
          img.onload = img.onerror = null;
          img.src = "";
        };
        img.onload = () => done(img.naturalWidth ? { width: img.naturalWidth, height: img.naturalHeight } : null, cleanup);
        img.onerror = () => done(null, cleanup);
        img.src = item.url;
      } else {
        const video = document.createElement("video");
        cleanup = () => {
          video.onloadedmetadata = video.onerror = null;
          video.removeAttribute("src");
          video.load();
        };
        video.preload = "metadata";
        video.muted = true;
        video.onloadedmetadata = () => done(video.videoWidth ? {
          width: video.videoWidth,
          height: video.videoHeight,
          ...Number.isFinite(video.duration) ? { durationSec: Math.round(video.duration * 10) / 10 } : {}
        } : null, cleanup);
        video.onerror = () => done(null, cleanup);
        video.src = item.url;
      }
    });
  }
  async function handOver(runId, json) {
    const ready = await chrome.runtime.sendMessage({ type: "prepare-file", runId }).catch(() => null);
    if (!ready?.ok) return null;
    return new Promise((resolve) => {
      const port = chrome.runtime.connect({ name: FILE_PORT });
      const timer = setTimeout(() => {
        port.disconnect();
        resolve(null);
      }, 12e4);
      port.onMessage.addListener((message) => {
        clearTimeout(timer);
        port.disconnect();
        resolve(message.url ?? null);
      });
      port.onDisconnect.addListener(() => {
        clearTimeout(timer);
        resolve(null);
      });
      for (let at = 0; at < json.length; at += FILE_CHUNK_CHARS) port.postMessage({ chunk: json.slice(at, at + FILE_CHUNK_CHARS) });
      port.postMessage({ end: true });
    });
  }
  function digestOf(output, bytes) {
    const pageId = output.advertiser.page_id;
    const pageName = output.advertiser.page_name ?? "";
    let low = 0, partner = 0, gated = 0;
    for (const ad of output.ads) {
      const details = libraryDetails(ad.raw, { pageId, pageName });
      if (details.lowImpressions) low += 1;
      if (details.partner) partner += 1;
      if (ad.raw?.gated_type === "LOGGED_OUT") gated += 1;
    }
    return {
      advertiser: output.advertiser,
      inputUrl: output.input_url,
      complete: output.complete,
      stoppedReason: output.stopped_reason,
      summary: output.summary,
      ids: output.ads.map((a) => a.library_id),
      gatedAds: gated,
      lowImpressionAds: low,
      partnershipAds: partner,
      bytes
    };
  }
  var EMPTY_SCROLLS_TO_END = 6;
  async function run(config) {
    const { id, options } = config;
    const knownIds = config.knownIds ? new Set(config.knownIds) : null;
    const toEnd = options.maxPages == null;
    if (document.readyState === "loading") await new Promise((done) => document.addEventListener("DOMContentLoaded", done, { once: true }));
    const widget = mountWidget();
    const results = new ResultsAccumulator();
    const warnings = /* @__PURE__ */ new Set();
    let block = null;
    let version = 0;
    let stopRequested = false;
    let phase = "opening";
    const progress = { pagesLoaded: 0, maxPages: options.maxPages ?? 0, toEnd, ads: 0, metaTotal: null, nextScrollAt: null, emptyScrolls: 0 };
    const emptyLimit = toEnd ? EMPTY_SCROLLS_TO_END : EMPTY_SCROLLS_TO_STOP;
    const report = (next, status, warning) => {
      phase = next;
      void send({ type: "progress", runId: id, phase, status, progress: { ...progress }, ...warning ? { warning } : {} });
    };
    const warn = (message) => {
      if (!warnings.has(message)) {
        warnings.add(message);
        report(phase, statusLine(), message);
      }
    };
    const flag = (signal2) => {
      if (!block) block = signal2;
    };
    const refresh = () => {
      const state = results.result;
      progress.pagesLoaded = state.pagesLoaded;
      progress.ads = state.ads.length;
      progress.metaTotal = state.metaReportedTotal;
      if (toEnd && state.metaReportedTotal != null) progress.maxPages = Math.max(pagesFor(state.metaReportedTotal), state.pagesLoaded);
      return state;
    };
    const statusLine = () => {
      const ads = `${progress.ads.toLocaleString("en-US")}${toEnd && progress.metaTotal != null ? ` of ~${progress.metaTotal.toLocaleString("en-US")}` : ""} ads`;
      return toEnd ? `Read ${progress.pagesLoaded} of ${progress.maxPages ? `~${progress.maxPages}` : "?"} pages \xB7 ${ads}` : `Read ${progress.pagesLoaded} of ${options.maxPages} pages \xB7 ${ads}`;
    };
    const take = (item) => {
      if (item.block) {
        flag(item.block);
        return;
      }
      if (item.warning) warn(item.warning);
      if (!item.results) return;
      if (!results.add(item.record).length) return;
      version += 1;
      const state = refresh();
      if (silentEmptyPage(state)) flag({ reason: "A results page came back empty while Meta said more were coming" });
      report(phase === "opening" ? "collecting" : phase, statusLine());
    };
    chrome.runtime.onMessage.addListener((message) => {
      if (message?.type === "stop" && message.runId === id) stopRequested = true;
      if (message?.type === "state" && message.run.id === id) widget.update(message.run);
    });
    widget.onStop(() => {
      stopRequested = true;
    });
    widget.onShowFile(() => {
      void chrome.runtime.sendMessage({ type: "show-file" });
    });
    const finish = async (complete, stoppedReason) => {
      onCaptured = null;
      const state = refresh();
      const blocked = block;
      const reason = blocked ? `blocked: ${blocked.reason}` : complete ? null : stoppedReason;
      if (!state.ads.length && !blocked) {
        const hint = /view_all_page_id=/.test(options.url) ? " If the Ad Library shows ads for this advertiser, check the Page ID: it's the number after view_all_page_id=, not the Facebook profile ID." : "";
        void send({ type: "failed", runId: id, error: `No ads were collected (${stoppedReason ?? "no results"}).${hint}` });
        return;
      }
      const output = buildOutput(state, {
        input_url: options.url,
        scraped_at: (/* @__PURE__ */ new Date()).toISOString(),
        country: new URL(options.url).searchParams.get("country") ?? "ALL",
        active_only: new URL(options.url).searchParams.get("active_status") !== "all",
        complete: !blocked && complete,
        stopped_reason: reason
      });
      if (options.measure && !blocked && output.ads.length) {
        const items = mediaToMeasure(output, MAX_MEASURED_ADS);
        progress.measured = 0;
        progress.toMeasure = items.length;
        report("measuring", `Measuring media sizes (0 of ${items.length})`);
        const sizes = /* @__PURE__ */ new Map();
        for (const item of items) {
          if (stopRequested) break;
          const size = await measure(item);
          if (size) sizes.set(item.key, size);
          progress.measured += 1;
          report("measuring", `Measuring media sizes (${progress.measured} of ${items.length})`);
          await sleep(measureGapMs());
        }
        applyMeasurements(output, sizes);
      }
      output.collector = config.collector;
      output.run_safety = {
        runs_today: config.safety.runsToday,
        minutes_since_previous_run: config.safety.minutesSincePrevious,
        concurrent_runs: 0,
        overrides: config.safety.acceptedWarnings.length ? ["accepted warnings in the extension"] : [],
        warnings: [...config.safety.acceptedWarnings, ...warnings]
      };
      report("saving", `Saving ${output.ads.length.toLocaleString("en-US")} ads\u2026`);
      const json = JSON.stringify(output);
      const fileUrl = await handOver(id, json);
      void send({ type: "finished", runId: id, digest: digestOf(output, json.length), fileUrl, block: blocked });
    };
    report("opening", "Opening the Ad Library\u2026");
    const embedded = embeddedResults();
    if (embedded.length) {
      results.add({ data: embedded });
      version += 1;
      refresh();
    }
    onCaptured = take;
    early.splice(0).forEach(take);
    const waitFor = async (condition, ms) => {
      let left = ms;
      while (left > 0) {
        if (condition() || block || stopRequested) return condition();
        if (document.hidden) {
          await pausedUntilVisible();
          continue;
        }
        await sleep(250);
        left -= 250;
      }
      return condition();
    };
    const pausedUntilVisible = async () => {
      const resume = phase;
      report("paused", "Paused: the collector window is minimized or covered. Bring it back into view to continue");
      while (document.hidden && !stopRequested) await sleep(500);
      report(resume, statusLine());
    };
    await sleep(1500);
    let signal = pageBlock();
    if (signal) {
      flag(signal);
      return finish(false, null);
    }
    const consent = async () => {
      let found = consentDialog();
      if (!found) return true;
      if (found.privateChoice) {
        found.privateChoice.click();
        await sleep(1500);
        found = consentDialog();
        if (!found) return true;
      }
      const resume = phase;
      report("consent", "Choose a cookie option on the page to continue");
      const deadline = Date.now() + CONSENT_WAIT_MS;
      while (Date.now() < deadline && !stopRequested) {
        await sleep(1e3);
        if (!consentDialog()) {
          report(resume, statusLine());
          return true;
        }
      }
      return false;
    };
    if (!await consent()) return finish(false, "the cookie dialog was not closed within 5 minutes");
    if (!await waitFor(() => version > 0, FIRST_RESULTS_MS)) {
      if (stopRequested) return finish(false, "stopped");
      if (!block) {
        const shown = cardsOnScreen();
        if (shown > 0) {
          void send({ type: "failed", runId: id, error: `The page shows ${shown} ads but the extension couldn't read them. Meta may have changed the page; the extension needs an update. Nothing was blocked.` });
          onCaptured = null;
          return;
        }
        flag(pageBlock() ?? { reason: `No results arrived within ${FIRST_RESULTS_MS / 1e3} s of the page loading (silent block)` });
      }
      return finish(false, null);
    }
    refresh();
    report("collecting", statusLine());
    for (; ; ) {
      if (block) return finish(false, null);
      if (stopRequested) return finish(false, "stopped from the extension");
      const state = refresh();
      if (state.hasNextPage === false) return finish(true, null);
      if (!toEnd && state.pagesLoaded >= (options.maxPages ?? 0)) return finish(false, `reached the page limit (${options.maxPages})`);
      if (!toEnd && caughtUp(state, knownIds)) return finish(false, `caught up: ${KNOWN_PAGES_TO_STOP} pages in a row held only ads from the last run`);
      if (progress.emptyScrolls >= emptyLimit) {
        return finish(false, toEnd ? `Meta stopped sending more results after ${state.ads.length.toLocaleString("en-US")} ads (${emptyLimit} scrolls loaded nothing, though it said more were coming)` : `${emptyLimit} scrolls in a row loaded nothing new`);
      }
      const pause = scrollPauseMs();
      progress.nextScrollAt = Date.now() + pause;
      report("collecting", statusLine());
      let left = pause;
      while (left > 0 && !block && !stopRequested) {
        if (document.hidden) {
          await pausedUntilVisible();
          progress.nextScrollAt = Date.now() + left;
          report("collecting", statusLine());
          continue;
        }
        await sleep(250);
        left -= 250;
      }
      progress.nextScrollAt = null;
      if (block || stopRequested) continue;
      signal = pageBlock();
      if (signal) {
        flag(signal);
        continue;
      }
      if (!await consent()) return finish(false, "the cookie dialog was not closed within 5 minutes");
      const before = version;
      if (progress.emptyScrolls > 0) {
        window.scrollBy({ top: -900, behavior: "auto" });
        await sleep(600 + Math.round(Math.random() * 600));
      }
      await scrollDown();
      const loaded = await waitFor(() => version > before, NEXT_RESULTS_MS);
      progress.emptyScrolls = loaded ? 0 : progress.emptyScrolls + 1;
      report("collecting", loaded ? statusLine() : `No new results after that scroll (${progress.emptyScrolls} of ${emptyLimit}); trying again`);
    }
  }
  void (async () => {
    const config = await hello();
    if (!config) {
      early.length = 0;
      return;
    }
    try {
      await run(config);
    } catch (error) {
      void send({ type: "failed", runId: config.id, error: `The run stopped unexpectedly: ${error.message}` });
    }
  })();
})();
