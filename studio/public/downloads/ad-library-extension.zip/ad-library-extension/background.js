"use strict";
(() => {
  // scripts/meta-ad-library/src/shared.ts
  var WARN_ABOVE_PAGES = 15;
  var HARD_MAX_PAGES = 30;
  var COOLDOWN_MS = 6 * 60 * 60 * 1e3;
  var MIN_GAP_MS = 30 * 60 * 1e3;
  var DAILY_SOFT_CAP = 20;
  var pad = (n) => String(n).padStart(2, "0");
  var localDay = (d = /* @__PURE__ */ new Date()) => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  function slugify(text) {
    return text.normalize("NFKD").replace(/[̀-ͯ]/g, "").toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-+|-+$/g, "").slice(0, 60);
  }

  // scripts/meta-ad-library/src/normalizer.ts
  var urlParam = (url, key) => {
    try {
      return new URL(url).searchParams.get(key);
    } catch {
      return null;
    }
  };
  function pageSlug(advertiser, inputUrl) {
    if (advertiser.page_id) {
      const name = advertiser.page_name ? slugify(advertiser.page_name) : "";
      return name ? `${name}-${advertiser.page_id}` : `page-${advertiser.page_id}`;
    }
    const q = urlParam(inputUrl, "q");
    return q ? `search-${slugify(q) || "terms"}` : "ad-library";
  }

  // chrome-extension/src/i18n.ts
  function messageKey(english) {
    let hash = 2166136261;
    for (let i = 0; i < english.length; i++) hash = Math.imul(hash ^ english.charCodeAt(i), 16777619) >>> 0;
    const slug = english.toLowerCase().replace(/\$\d/g, "n").replace(/[^a-z0-9]+/g, "_").replace(/^_+|_+$/g, "").split("_").slice(0, 5).join("_");
    return `m_${slug ? `${slug}_` : ""}${hash.toString(16).padStart(8, "0")}`;
  }
  var fillSubs = (text, subs) => text.replace(/\$(\d)/g, (whole, n) => subs[Number(n) - 1] ?? whole);
  var i18n = () => {
    const c = globalThis.chrome;
    return c?.i18n && typeof c.i18n.getMessage === "function" ? c.i18n : null;
  };
  function uiLocale() {
    try {
      return i18n()?.getUILanguage() || "en-US";
    } catch {
      return "en-US";
    }
  }
  var fmtNumber = (n) => n.toLocaleString(uiLocale());
  function tr(english, ...subs) {
    const values = subs.map((s) => typeof s === "number" ? fmtNumber(s) : s);
    try {
      const found = i18n()?.getMessage(messageKey(english), values);
      if (found) return found;
    } catch {
    }
    return fillSubs(english, values);
  }
  var trn = (n, one, other, ...subs) => n === 1 ? tr(one, n, ...subs) : tr(other, n, ...subs);

  // chrome-extension/src/protocol.ts
  var EXTENSION_NAME = "Ad Library Collector";
  var DOWNLOAD_FOLDER = "Ad Library";

  // chrome-extension/src/background.ts
  var VERSION = chrome.runtime.getManifest().version;
  var ACTIVE = ["opening", "consent", "collecting", "paused", "measuring", "saving"];
  var SILENT_MS = 9e4;
  var TAB_TYPES = /* @__PURE__ */ new Set(["hello", "progress", "prepare-file", "finished", "failed"]);
  var session = chrome.storage.session;
  var local = chrome.storage.local;
  var NOTIFICATION_PREFIX = "ad-library-";
  var getRun = async () => (await session.get("run")).run ?? null;
  async function putRun(run) {
    if (run) await session.set({ run });
    else await session.remove("run");
    if (run) chrome.tabs.sendMessage(run.tabId, { type: "state", run }).catch(() => void 0);
  }
  var getLocal = async (key, fallback) => (await local.get(key))[key] ?? fallback;
  async function activeCooldown(now = Date.now()) {
    const c = await getLocal("cooldown", null);
    return c && c.until > now ? c : null;
  }
  var clock = (ms) => new Date(ms).toLocaleTimeString(uiLocale(), { hour: "2-digit", minute: "2-digit" });
  function pageKey(url) {
    try {
      const u = new URL(url);
      const id = u.searchParams.get("view_all_page_id");
      const q = u.searchParams.get("q");
      const scope = `${(u.searchParams.get("country") ?? "ALL").toUpperCase()}:${u.searchParams.get("active_status") === "all" ? "all" : "active"}`;
      return id ? `page:${id}:${scope}` : q ? `search:${q.trim().toLowerCase()}:${scope}` : null;
    } catch {
      return null;
    }
  }
  async function liveRun() {
    const run = await getRun();
    if (!run || !ACTIVE.includes(run.phase)) return null;
    if (Date.now() - run.heartbeatAt < SILENT_MS) return run;
    const tab = await chrome.tabs.get(run.tabId).catch(() => null);
    if (tab) return run;
    await fail(run, tr("The Ad Library tab went away mid-run. Nothing was saved."));
    return null;
  }
  async function preflight(options) {
    const now = Date.now();
    const cooldown = await activeCooldown(now);
    const ledger = await getLocal("ledger", {});
    const runsToday = (ledger[localDay()] ?? []).length;
    const last = Object.values(ledger).flat().map((e) => e.startedAt).sort((a, b) => b - a)[0];
    const minutesSincePrevious = last ? Math.round((now - last) / 6e4) : null;
    const running = await liveRun();
    let refusal = null;
    if (cooldown) refusal = tr("Meta showed a block sign at $1 ($2). The next run is possible at $3.", clock(cooldown.since), cooldown.reason, clock(cooldown.until));
    else if (running) refusal = tr("A run is already going in another tab. One run at a time.");
    else if (!/^https:\/\/www\.facebook\.com\/ads\/library\//.test(options.url)) refusal = tr("That isn't a Meta Ad Library link.");
    const warnings = [];
    if (last && now - last < MIN_GAP_MS) warnings.push(tr("The last run started $1 min ago. Runs should be at least $2 min apart: back-to-back runs are a main reason Meta limits a connection.", minutesSincePrevious ?? 0, MIN_GAP_MS / 6e4));
    if (runsToday >= DAILY_SOFT_CAP) warnings.push(tr("This would be run $1 today (the suggested limit is $2). Frequent visits from one connection can get it challenged.", runsToday + 1, DAILY_SOFT_CAP));
    if (options.maxPages != null && options.maxPages > WARN_ABOVE_PAGES) warnings.push(tr("$1 pages is above the suggested $2. More pages raise the chance Meta limits this connection.", options.maxPages, WARN_ABOVE_PAGES));
    return { refusal, cooldown, warnings, runsToday, minutesSincePrevious };
  }
  async function start(options, acceptedWarnings, useTabId) {
    const clean = { ...options, maxPages: options.maxPages == null ? null : Math.max(1, Math.min(HARD_MAX_PAGES, Math.round(options.maxPages))) };
    const check = await preflight(clean);
    if (check.refusal) throw new Error(check.refusal);
    const unaccepted = check.warnings.filter((w) => !acceptedWarnings.includes(w));
    if (unaccepted.length) throw new Error(tr("Please confirm first: $1", unaccepted[0]));
    const tab = await openRunWindow();
    if (tab?.id == null) throw new Error(tr("Couldn't open a window for the Ad Library."));
    const now = Date.now();
    const run = {
      id: crypto.randomUUID(),
      tabId: tab.id,
      windowId: tab.windowId ?? null,
      options: clean,
      phase: "opening",
      startedAt: now,
      heartbeatAt: now,
      progress: { pagesLoaded: 0, maxPages: clean.maxPages ?? 0, toEnd: clean.maxPages == null, ads: 0, metaTotal: null, nextScrollAt: null, emptyScrolls: 0 },
      status: tr("Opening the Ad Library\u2026"),
      warnings: [],
      acceptedWarnings
    };
    const ledger = await getLocal("ledger", {});
    const day = localDay();
    ledger[day] = [...ledger[day] ?? [], { startedAt: now, url: clean.url }];
    for (const key of Object.keys(ledger).sort().slice(0, -14)) delete ledger[key];
    await local.set({ ledger });
    await putRun(run);
    await chrome.tabs.update(tab.id, { url: clean.url, active: true });
    return run;
  }
  async function openRunWindow() {
    const current = await chrome.windows.getLastFocused().catch(() => null);
    const displays = await chrome.system.display.getInfo().catch(() => []);
    const cx = (current?.left ?? 0) + (current?.width ?? 0) / 2;
    const cy = (current?.top ?? 0) + (current?.height ?? 0) / 2;
    const screen = (displays.find((d) => cx >= d.workArea.left && cx < d.workArea.left + d.workArea.width && cy >= d.workArea.top && cy < d.workArea.top + d.workArea.height) ?? displays.find((d) => d.isPrimary) ?? displays[0])?.workArea;
    const width = 480;
    const height = screen ? Math.min(900, screen.height) : 800;
    const left = screen ? screen.left + screen.width - width : void 0;
    const top = screen ? screen.top : void 0;
    const win = await chrome.windows.create({ url: "about:blank", type: "popup", width, height, left, top, focused: true });
    return win?.tabs?.[0];
  }
  async function setOutcome(run, outcome) {
    const ledger = await getLocal("ledger", {});
    for (const entries of Object.values(ledger)) {
      const mine = entries.find((e) => e.startedAt === run.startedAt);
      if (mine) mine.outcome = outcome;
    }
    await local.set({ ledger });
  }
  async function fail(run, error) {
    const done = { ...run, phase: "failed", error, status: error, heartbeatAt: Date.now() };
    await putRun(done);
    await local.set({ last: done });
    await setOutcome(run, `failed: ${error}`);
  }
  async function ensureOffscreen() {
    if (await chrome.offscreen.hasDocument()) return;
    await chrome.offscreen.createDocument({ url: "offscreen.html", reasons: [chrome.offscreen.Reason.BLOBS], justification: "Turn a finished Ad Library file into a download" }).catch((error) => {
      if (!/single offscreen/i.test(error.message)) throw error;
    });
  }
  var pendingFiles = /* @__PURE__ */ new Map();
  chrome.downloads.onChanged.addListener(async (delta) => {
    const url = pendingFiles.get(delta.id);
    if (!url || !delta.state || delta.state.current === "in_progress") return;
    pendingFiles.delete(delta.id);
    await chrome.runtime.sendMessage({ type: "ad-library:revoke", url }).catch(() => void 0);
    if (!pendingFiles.size) await chrome.offscreen.closeDocument().catch(() => void 0);
  });
  async function finished(run, digest, fileUrl, block) {
    const now = Date.now();
    let cooldown = null;
    if (block) {
      cooldown = { since: now, until: now + COOLDOWN_MS, reason: block.reason };
      await local.set({ cooldown });
    }
    const key = pageKey(run.options.url);
    const history = await getLocal("history", {});
    const before = key ? history[key] : void 0;
    const ids = digest.ids;
    let diff = null;
    if (before) {
      const was = new Set(before.ids);
      const is = new Set(ids);
      diff = { added: ids.filter((id) => !was.has(id)).length, gone: before.ids.filter((id) => !is.has(id)).length, still: ids.filter((id) => was.has(id)).length };
    }
    if (key && ids.length) {
      const kept = digest.complete ? ids : [.../* @__PURE__ */ new Set([...ids, ...before?.ids ?? []])];
      history[key] = { day: localDay(), complete: digest.complete, ids: kept.slice(0, 5e4), pageName: digest.advertiser.page_name };
      await local.set({ history });
    }
    const fileName = `${pageSlug(digest.advertiser, digest.inputUrl)}-${localDay()}.json`;
    let downloadId = null;
    let saveError = null;
    if (fileUrl) {
      downloadId = await chrome.downloads.download({ url: fileUrl, filename: `${DOWNLOAD_FOLDER}/${fileName}`, conflictAction: "overwrite", saveAs: false }).catch((error) => {
        saveError = error.message;
        return null;
      });
      if (downloadId != null) pendingFiles.set(downloadId, fileUrl);
    } else saveError = "the file couldn't be prepared";
    const pageId = digest.advertiser.page_id;
    const pageName = digest.advertiser.page_name;
    const summary = {
      fileName: `${DOWNLOAD_FOLDER}/${fileName}`,
      downloadId,
      pageName,
      pageId,
      totalAds: digest.summary.total_ads,
      activeAds: digest.summary.active_ads,
      complete: digest.complete,
      stoppedReason: digest.stoppedReason,
      gatedAds: digest.gatedAds,
      lowImpressionAds: digest.lowImpressionAds,
      partnershipAds: digest.partnershipAds,
      creativeTypes: digest.summary.creative_types,
      diff
    };
    const done = block ? { ...run, phase: "blocked", summary, error: tr("Meta showed a block sign: $1. The extension stopped without trying to get around it.", block.reason), cooldownUntil: cooldown?.until, status: tr("Stopped: Meta limited this connection"), heartbeatAt: now } : saveError ? { ...run, phase: "failed", summary, error: tr("Collected $1 ads but couldn't save the file ($2). Try again.", summary.totalAds, saveError), status: tr("Couldn't save the file"), heartbeatAt: now } : { ...run, phase: "done", summary, status: trn(summary.totalAds, "$1 ad saved", "$1 ads saved"), heartbeatAt: now };
    await putRun(done);
    await local.set({ last: done });
    await setOutcome(run, block ? `blocked: ${block.reason}` : saveError ? `not saved: ${saveError}` : digest.complete ? "complete" : `stopped: ${digest.stoppedReason ?? ""}`);
    chrome.notifications.create(`${NOTIFICATION_PREFIX}${run.id}`, {
      type: "basic",
      iconUrl: "icons/icon128.png",
      title: block ? tr("Meta limited this connection") : saveError ? tr("Couldn't save the file") : `${trn(summary.totalAds, "$1 ad saved", "$1 ads saved")}${pageName ? ` \xB7 ${pageName}` : ""}`,
      message: block ? tr("Stopped and saved $1 ads. Next run possible at $2.", summary.totalAds, clock(cooldown.until)) : saveError ? tr("$1 ads were collected, but the file couldn't be saved.", summary.totalAds) : tr("Saved to Downloads/$1. Drag it onto your dashboard's Research page to import.", summary.fileName),
      buttons: downloadId != null ? [{ title: tr("Show in Finder") }] : [],
      priority: 1
    });
  }
  async function onPopup(message) {
    switch (message.type) {
      case "state": {
        await liveRun();
        const ledger = await getLocal("ledger", {});
        return { run: await getRun(), cooldown: await activeCooldown(), runsToday: (ledger[localDay()] ?? []).length, last: await getLocal("last", null) };
      }
      case "preflight":
        return preflight(message.options);
      case "start":
        return start(message.options, message.acceptedWarnings, message.useTabId);
      case "stop": {
        const run = await getRun();
        if (run && ACTIVE.includes(run.phase)) {
          await putRun({ ...run, status: tr("Stopping and saving\u2026") });
          await chrome.tabs.sendMessage(run.tabId, { type: "stop", runId: run.id }).catch(async () => fail(run, tr("The Ad Library tab didn't answer. Nothing was saved.")));
        }
        return { ok: true };
      }
      case "show-file": {
        const run = await getRun() ?? await getLocal("last", null);
        const id = run?.summary?.downloadId;
        if (id != null) chrome.downloads.show(id);
        return { ok: id != null };
      }
      case "focus-run": {
        const run = await getRun();
        if (run) {
          await chrome.tabs.update(run.tabId, { active: true }).catch(() => void 0);
          if (run.windowId != null) await chrome.windows.update(run.windowId, { focused: true }).catch(() => void 0);
        }
        return { ok: true };
      }
      case "clear": {
        const run = await getRun();
        if (run && ACTIVE.includes(run.phase)) throw new Error("A run is still going. Stop it first.");
        await putRun(null);
        return { ok: true };
      }
    }
  }
  async function onTab(message, tabId) {
    const run = await getRun();
    if (message.type === "hello") {
      if (!run || run.tabId !== tabId || !ACTIVE.includes(run.phase)) return { run: null };
      if (run.phase !== "opening") {
        await fail(run, tr("The Ad Library tab was reloaded mid-run. Start a new run."));
        return { run: null };
      }
      const key = pageKey(run.options.url);
      const activeOnly = new URL(run.options.url).searchParams.get("active_status") !== "all";
      const history = key && activeOnly && run.options.maxPages != null ? (await getLocal("history", {}))[key] : void 0;
      const ledger = await getLocal("ledger", {});
      const previous = Object.values(ledger).flat().map((e) => e.startedAt).filter((t) => t < run.startedAt).sort((a, b) => b - a)[0];
      return {
        run: {
          id: run.id,
          options: run.options,
          knownIds: history?.ids ?? null,
          collector: `chrome-extension@${VERSION}`,
          safety: {
            runsToday: (ledger[localDay()] ?? []).length,
            minutesSincePrevious: previous ? Math.round((run.startedAt - previous) / 6e4) : null,
            acceptedWarnings: run.acceptedWarnings
          }
        }
      };
    }
    if (!run || run.id !== message.runId || !ACTIVE.includes(run.phase)) return { ok: false };
    if (message.type === "progress") {
      const warnings = message.warning && !run.warnings.includes(message.warning) ? [...run.warnings, message.warning] : run.warnings;
      await putRun({ ...run, phase: message.phase, status: message.status, progress: { ...run.progress, ...message.progress }, warnings, heartbeatAt: Date.now() });
      return { ok: true };
    }
    if (message.type === "prepare-file") {
      await ensureOffscreen();
      return { ok: true };
    }
    if (message.type === "finished") {
      await finished(run, message.digest, message.fileUrl, message.block);
      return { ok: true };
    }
    if (message.type === "failed") {
      await fail(run, message.error);
      return { ok: true };
    }
    return { ok: false };
  }
  chrome.runtime.onMessage.addListener((message, sender, reply) => {
    const fromTab = TAB_TYPES.has(message?.type);
    if (fromTab && !sender.tab?.url?.startsWith("https://www.facebook.com/ads/library")) {
      reply({ error: "Not an Ad Library tab" });
      return false;
    }
    const job = fromTab ? onTab(message, sender.tab?.id) : onPopup(message);
    job.then(reply, (error) => reply({ error: error.message }));
    return true;
  });
  chrome.notifications.onButtonClicked.addListener(async (id) => {
    if (!id.startsWith(NOTIFICATION_PREFIX)) return;
    const last = await getLocal("last", null);
    if (last?.summary?.downloadId != null) chrome.downloads.show(last.summary.downloadId);
  });
  chrome.notifications.onClicked.addListener(async (id) => {
    if (!id.startsWith(NOTIFICATION_PREFIX)) return;
    const last = await getLocal("last", null);
    if (last?.summary?.downloadId != null) chrome.downloads.show(last.summary.downloadId);
  });
  chrome.tabs.onRemoved.addListener(async (tabId) => {
    const run = await getRun();
    if (run && run.tabId === tabId && ACTIVE.includes(run.phase)) await fail(run, tr("The Ad Library tab was closed mid-run. Nothing was saved."));
  });
  chrome.runtime.onInstalled.addListener(() => console.info(`${EXTENSION_NAME} ${VERSION} ready`));
})();
