"use strict";
(() => {
  // chrome-extension/src/protocol.ts
  var EXTENSION_NAME = "Ad Library Collector";
  var DEFAULT_DASHBOARD_URL = "http://localhost:3000";
  var DASHBOARD_KEY = "dashboardUrl";
  function cleanDashboardUrl(value) {
    const text = value.trim();
    if (!text) return null;
    const local = /^(localhost|127\.0\.0\.1|\[::1\])(:\d+)?(\/|$)/i.test(text);
    try {
      const url = new URL(/^[a-z][a-z0-9+.-]*:\/\//i.test(text) ? text : `${local ? "http" : "https"}://${text}`);
      return (url.protocol === "http:" || url.protocol === "https:") && url.hostname ? url.origin : null;
    } catch {
      return null;
    }
  }
  var dashboardAppUrl = (base) => `${base.replace(/\/+$/, "")}/app`;
  async function loadDashboardUrl() {
    try {
      const stored = (await chrome.storage.local.get(DASHBOARD_KEY))[DASHBOARD_KEY];
      return typeof stored === "string" && cleanDashboardUrl(stored) || DEFAULT_DASHBOARD_URL;
    } catch {
      return DEFAULT_DASHBOARD_URL;
    }
  }
  async function saveDashboardUrl(value) {
    if (!value.trim()) {
      await chrome.storage.local.remove(DASHBOARD_KEY);
      return DEFAULT_DASHBOARD_URL;
    }
    const clean = cleanDashboardUrl(value);
    if (!clean) return null;
    await chrome.storage.local.set({ [DASHBOARD_KEY]: clean });
    return clean;
  }
  var DOWNLOAD_FOLDER = "Ad Library";
  var ADS_PER_PAGE = 28;
  var SECONDS_PER_PAGE = 9;
  var LONG_RUN_PAGES = 45;
  var pagesFor = (total) => Math.max(1, Math.ceil(total / ADS_PER_PAGE));

  // chrome-extension/src/ui-common.ts
  function logoSvg(size, key = "a") {
    return `<svg width="${size}" height="${size}" viewBox="0 0 28 28" aria-hidden="true" focusable="false"><defs><linearGradient id="rl-g-${key}" x1="0" y1="0" x2="1" y2="1"><stop offset="0" stop-color="#f59e4b"/><stop offset="1" stop-color="#e0621a"/></linearGradient></defs><rect width="28" height="28" rx="8" fill="url(#rl-g-${key})"/><path d="M8 .5h12a7.5 7.5 0 0 1 7.5 7.5" fill="none" stroke="#fff" stroke-opacity=".3" stroke-width="1"/><circle cx="14" cy="14" r="6" fill="none" stroke="#fff" stroke-opacity=".85" stroke-width="2"/><circle cx="14" cy="14" r="3" fill="#fff"/></svg>`;
  }
  var ACTIVE_PHASES = ["opening", "consent", "collecting", "paused", "measuring", "saving"];
  var isActive = (run) => !!run && ACTIVE_PHASES.includes(run.phase);
  var PHASE_LABEL = {
    opening: "Opening",
    consent: "Cookie choice",
    collecting: "Collecting",
    paused: "Paused",
    measuring: "Measuring",
    saving: "Saving",
    done: "Done",
    blocked: "Blocked",
    failed: "Failed"
  };
  function progressFraction(run) {
    const p = run.progress;
    if (run.phase === "measuring" && p.toMeasure) return clamp01((p.measured ?? 0) / p.toMeasure);
    if (run.phase === "saving" || run.phase === "done") return 1;
    return p.maxPages > 0 ? clamp01(p.pagesLoaded / p.maxPages) : 0;
  }
  var clamp01 = (n) => Number.isFinite(n) ? Math.max(0, Math.min(1, n)) : 0;
  function countdown(nextScrollAt, now = Date.now()) {
    if (nextScrollAt == null) return null;
    const s = (nextScrollAt - now) / 1e3;
    if (s <= 0) return null;
    return s < 10 ? `${s.toFixed(1)} s` : `${Math.ceil(s)} s`;
  }
  function clockTime(ms, now = Date.now()) {
    const d = new Date(ms);
    const time = d.toLocaleTimeString([], { hour: "numeric", minute: "2-digit" });
    return d.toDateString() === new Date(now).toDateString() ? time : `${d.toLocaleDateString([], { weekday: "short" })} ${time}`;
  }
  function duration(ms) {
    const min = Math.ceil(ms / 6e4);
    if (min <= 1) return ms <= 0 ? "now" : "under a minute";
    const h2 = Math.floor(min / 60), m = min % 60;
    return h2 ? m ? `${h2} h ${m} min` : `${h2} h` : `${m} min`;
  }
  function elapsed(since, now = Date.now()) {
    const s = Math.max(0, Math.floor((now - since) / 1e3));
    return `${Math.floor(s / 60)}:${String(s % 60).padStart(2, "0")}`;
  }
  var fmt = (n) => n.toLocaleString("en-US");
  var plural = (n, one, many = `${one}s`) => `${fmt(n)} ${n === 1 ? one : many}`;
  function isAdLibraryUrl(raw) {
    if (!raw) return false;
    try {
      const u = new URL(raw);
      return /(^|\.)facebook\.com$/i.test(u.hostname) && u.pathname.startsWith("/ads/library");
    } catch {
      return false;
    }
  }
  function pageIdUrl(pageId, country, activeOnly) {
    return `https://www.facebook.com/ads/library/?active_status=${activeOnly ? "active" : "all"}&ad_type=all&country=${country}&media_type=all&search_type=page&view_all_page_id=${pageId}`;
  }
  function targetUrl({ input, country, activeOnly }) {
    const c = country.trim().toUpperCase() || "ALL";
    if (!/^([A-Z]{2}|ALL)$/.test(c)) return { error: "Country is a two-letter code (US, GB\u2026) or ALL." };
    const v = input.trim();
    if (!v) return { error: "Paste an Ad Library link or a Page ID." };
    if (/^\d{5,}$/.test(v)) return { url: pageIdUrl(v, c, activeOnly) };
    if (/^\d+$/.test(v)) return { error: "That number looks too short for a Page ID." };
    let u;
    try {
      u = new URL(/^https?:\/\//i.test(v) ? v : `https://${v}`);
    } catch {
      return { error: "That isn't a link or a Page ID." };
    }
    if (!isAdLibraryUrl(u.toString())) return { error: "The link must be a facebook.com/ads/library page." };
    if (!u.searchParams.get("view_all_page_id") && !u.searchParams.get("q")) {
      return { error: "This link has no advertiser. Open the advertiser's page of ads in the Ad Library first." };
    }
    u.searchParams.set("active_status", activeOnly ? "active" : "all");
    u.searchParams.set("country", c);
    return { url: u.toString() };
  }
  function describeUrl(raw) {
    try {
      const u = new URL(raw);
      const page = u.searchParams.get("view_all_page_id");
      if (page) return `Page ${page}`;
      const q = u.searchParams.get("q");
      if (q) return `Search \u201C${q}\u201D`;
      return "Ad Library";
    } catch {
      return raw.slice(0, 40);
    }
  }

  // chrome-extension/src/popup.ts
  var PAGE_CHOICES = ["all", 5, 10, 20, 30];
  var PAGES_WARN_ABOVE = 15;
  var PREFS_KEY = "ad-library:prefs:v3";
  var EARLIER_PREFS_KEY = "radar-ad-library:prefs:v3";
  var OLD_PREFS_KEYS = ["radar-ad-library:prefs:v2", "radar-ad-library:prefs"];
  var reply = null;
  var replyError = null;
  var activeTab = null;
  var pending = null;
  var actionError = null;
  var form = { mode: "input", input: "", country: "ALL", activeOnly: true, maxPages: "all", measure: false, error: null };
  var tabInfo;
  var dashboardUrl = DEFAULT_DASHBOARD_URL;
  var dashboardForm = { open: false, input: "", error: null };
  var app = document.getElementById("app");
  async function send(req) {
    const res = await chrome.runtime.sendMessage(req);
    if (res && typeof res === "object" && "error" in res && typeof res.error === "string") throw new ReplyError(res.error);
    return res;
  }
  var ReplyError = class extends Error {
  };
  var errorText = (e, context) => e instanceof ReplyError ? e.message : `${context}: ${e.message}`;
  async function refresh() {
    try {
      reply = await send({ type: "state" });
      replyError = null;
    } catch (e) {
      replyError = e instanceof ReplyError ? e.message : `Couldn't reach the extension's background (${e.message}). Close and reopen this popup.`;
    }
    render();
  }
  var refreshTimer;
  function scheduleRefresh() {
    clearTimeout(refreshTimer);
    refreshTimer = setTimeout(refresh, 60);
  }
  function h(tag, props = null, ...children) {
    const el = document.createElement(tag);
    if (props) {
      if (props.class) el.className = props.class;
      if (props.id) el.id = props.id;
      if (props.text != null) el.textContent = props.text;
      if (props.html != null) el.innerHTML = props.html;
      for (const [k, v] of Object.entries(props.attrs ?? {})) {
        if (v === false || v == null) continue;
        el.setAttribute(k, v === true ? "" : String(v));
      }
      for (const [k, fn] of Object.entries(props.on ?? {})) if (fn) el.addEventListener(k, fn);
    }
    for (const c of children) if (c != null && c !== false) el.append(c);
    return el;
  }
  function button(label, variant, onClick, opts = {}) {
    return h("button", {
      class: ["btn", variant, opts.sm && "sm", opts.block && "block"].filter(Boolean).join(" "),
      id: opts.id,
      text: label,
      attrs: { type: "button", disabled: !!opts.disabled },
      on: { click: onClick }
    });
  }
  function toggle(id, checked, label, onChange) {
    const el = h("button", { class: "toggle", id, attrs: { type: "button", role: "switch", "aria-checked": String(checked), "aria-label": label } });
    el.addEventListener("click", () => {
      const next = el.getAttribute("aria-checked") !== "true";
      el.setAttribute("aria-checked", String(next));
      onChange(next);
    });
    return el;
  }
  function pill(run) {
    const tone = run.phase === "paused" || run.phase === "consent" ? "caution" : run.phase === "done" ? "win" : run.phase === "blocked" || run.phase === "failed" ? "warn" : "accent";
    return h("span", { class: `pill ${tone}` }, h("i"), PHASE_LABEL[run.phase]);
  }
  function render() {
    const focus = captureFocus();
    const run = reply?.run ?? null;
    const parts = [header(run)];
    if (replyError) parts.push(h("div", { class: "callout warn" }, h("span", { text: replyError })));
    else if (!reply) parts.push(h("div", { class: "card" }, h("p", { class: "help", text: "Loading\u2026" })));
    else if (run && isActive(run)) parts.push(...runningView(run));
    else if (run?.phase === "done") parts.push(...doneView(run));
    else if (run?.phase === "blocked") parts.push(...blockedView(run));
    else if (run?.phase === "failed") parts.push(...failedView(run));
    else parts.push(...idleView());
    if (actionError) parts.push(h("p", { class: "err", text: actionError }));
    parts.push(footer());
    app.replaceChildren(...parts.filter((p) => !!p));
    restoreFocus(focus);
    tick();
  }
  function header(run) {
    return h(
      "div",
      { class: "head" },
      h("span", { html: logoSvg(22) }),
      h("span", { class: "title", text: EXTENSION_NAME }),
      h("span", { class: "right" }, run && reply ? pill(run) : null)
    );
  }
  function footer() {
    const runs = reply?.runsToday ?? 0;
    return h(
      "div",
      { class: "foot" },
      h(
        "div",
        { class: "foot-row" },
        h("span", { class: "num", text: `Runs today: ${runs}` }),
        h("a", { text: "Open your dashboard", attrs: { href: dashboardAppUrl(dashboardUrl), target: "_blank", rel: "noopener" }, on: { click: openDashboard } })
      ),
      h("span", { text: "Runs in its own small window: keep working in other windows, just keep part of it visible." }),
      dashboardSetting()
    );
  }
  function dashboardSetting() {
    if (!dashboardForm.open) {
      return h(
        "div",
        { class: "foot-row" },
        h("span", { class: "foot-url", text: `Dashboard: ${dashboardUrl.replace(/^https?:\/\//, "")}`, attrs: { title: dashboardUrl } }),
        h("button", { class: "link", id: "dash-change", text: "Change", attrs: { type: "button" }, on: { click: () => {
          dashboardForm.open = true;
          dashboardForm.input = dashboardUrl;
          dashboardForm.error = null;
          render();
          focusById("dash-url");
        } } })
      );
    }
    const field = h("input", {
      class: `field${dashboardForm.error ? " invalid" : ""}`,
      id: "dash-url",
      attrs: { type: "url", value: dashboardForm.input, placeholder: DEFAULT_DASHBOARD_URL, spellcheck: false, autocomplete: "off", "aria-label": "Dashboard address" },
      on: {
        input: (e) => {
          dashboardForm.input = e.target.value;
        },
        keydown: (e) => {
          if (e.key === "Enter") void saveDashboard();
        }
      }
    });
    return h(
      "div",
      { class: "foot-setting" },
      h("label", { text: "Dashboard address", attrs: { for: "dash-url" } }),
      h("div", { class: "foot-row" }, field, button("Save", "secondary", () => void saveDashboard(), { sm: true }), button("Cancel", "ghost", () => {
        dashboardForm.open = false;
        render();
      }, { sm: true })),
      h("span", { class: dashboardForm.error ? "err" : void 0, text: dashboardForm.error ?? `Where your dashboard runs. Leave it empty for ${DEFAULT_DASHBOARD_URL}.` })
    );
  }
  async function saveDashboard() {
    try {
      const saved = await saveDashboardUrl(dashboardForm.input);
      if (!saved) {
        dashboardForm.error = "That isn't a web address. Try https://dashboard.example.com.";
        render();
        return;
      }
      dashboardUrl = saved;
      dashboardForm.open = false;
    } catch (e) {
      dashboardForm.error = `Couldn't save it: ${e.message}`;
    }
    render();
  }
  function warningsList(run) {
    if (!run.warnings.length) return null;
    return h("div", { class: "warnings" }, ...run.warnings.map((w) => h("span", { text: w })));
  }
  function idleView() {
    const cooldown = reply?.cooldown && reply.cooldown.until > Date.now() ? reply.cooldown : null;
    const busy = pending?.kind === "checking" || pending?.kind === "starting";
    const tabUsable = !!activeTab && isAdLibraryUrl(activeTab.url);
    const source = h("div", { class: "stack" }, h("span", { class: "section-label", text: "Advertiser" }));
    if (form.mode === "tab" && activeTab) {
      source.append(h(
        "div",
        { class: "thispage" },
        h("span", { class: "dot" }),
        h("span", { class: "what" }, h("b", { text: "Use this page" }), h("span", { text: describeUrl(activeTab.url), attrs: { title: activeTab.url } })),
        button("Change", "ghost", () => {
          form.mode = "input";
          form.input = "";
          form.error = null;
          render();
          focusById("src");
        }, { sm: true })
      ));
    } else {
      const input = h("input", {
        class: `field${form.error ? " invalid" : ""}`,
        id: "src",
        attrs: { type: "text", placeholder: "Ad Library link or Page ID", spellcheck: "false", autocomplete: "off", value: form.input },
        on: {
          input: (e) => {
            form.input = e.target.value;
            if (form.error) {
              form.error = null;
              render();
            }
          },
          keydown: (e) => {
            if (e.key === "Enter") collect();
          }
        }
      });
      input.value = form.input;
      source.append(input);
      source.append(h("p", { class: "help", text: "The Page ID is the number after view_all_page_id= in the Ad Library link, not the Facebook profile ID." }));
      if (tabUsable) {
        source.append(h("p", { class: "help" }, h("a", { text: "Use the Ad Library page in this tab", attrs: { href: "#" }, on: { click: (e) => {
          e.preventDefault();
          useTab();
          render();
        } } })));
      }
    }
    if (form.error) source.append(h("p", { class: "err", text: form.error }));
    const country = h("input", {
      class: "field short",
      id: "country",
      attrs: { type: "text", maxlength: 3, spellcheck: "false", autocomplete: "off", "aria-label": "Country", value: form.country },
      on: { input: (e) => {
        form.country = e.target.value.toUpperCase();
        if (form.error) {
          form.error = null;
          render();
        }
      } }
    });
    country.value = form.country;
    const seg = h(
      "div",
      { class: "seg", attrs: { role: "radiogroup", "aria-label": "Pages to read" } },
      ...PAGE_CHOICES.map((n) => h("button", {
        text: n === "all" ? "All" : String(n),
        attrs: { type: "button", role: "radio", "aria-checked": String(form.maxPages === n) },
        on: { click: () => {
          form.maxPages = n;
          savePrefs();
          render();
        } }
      }))
    );
    const opts = h(
      "div",
      { class: "opts" },
      h("div", { class: "opt" }, h("label", { text: "Country", attrs: { for: "country" } }), country),
      h("div", { class: "opt" }, h("span", { text: "Active ads only" }), toggle("active", form.activeOnly, "Active ads only", (v) => {
        form.activeOnly = v;
        savePrefs();
      })),
      h("div", { class: "opt" }, h("span", { text: "Ads to read" }), seg),
      h("p", { class: "help", text: pagesHint() }),
      form.maxPages !== "all" && form.maxPages > PAGES_WARN_ABOVE ? h("p", { class: "inline-caution", text: "More pages raise the chance Meta limits this connection." }) : null,
      h("div", { class: "opt" }, h("span", { text: "Measure media sizes" }), toggle("measure", form.measure, "Measure media sizes", (v) => {
        form.measure = v;
        savePrefs();
      }))
    );
    const card = h("div", { class: "card" }, source, opts);
    if (cooldown) {
      card.append(h(
        "div",
        { class: "callout warn" },
        h("span", { class: "t", text: "Meta limited this connection" }),
        h("span", { text: `Next run possible at ${clockTime(cooldown.until)} (in ` }, h("span", { id: "cooldown-left", text: duration(cooldown.until - Date.now()) }), ").")
      ));
    } else if (pending?.kind === "refusal") {
      card.append(h("div", { class: "callout warn" }, h("span", { text: pending.text })));
    } else if (pending?.kind === "warnings") {
      const p = pending;
      card.append(h(
        "div",
        { class: "callout caution" },
        h("span", { class: "t", text: p.warnings.length === 1 ? "Before you run" : `${p.warnings.length} things before you run` }),
        h("ul", null, ...p.warnings.map((w) => h("li", { text: w }))),
        h(
          "div",
          { class: "actions" },
          button("Run anyway", "primary", () => start(p.options, p.warnings, p.useTabId), { sm: true }),
          button("Cancel", "secondary", () => {
            pending = null;
            render();
          }, { sm: true })
        )
      ));
    }
    if (pending?.kind !== "warnings") {
      const label = pending?.kind === "checking" ? "Checking\u2026" : pending?.kind === "starting" ? "Starting\u2026" : "Collect ads";
      card.append(button(label, "primary", collect, { block: true, disabled: busy || !!cooldown, id: "collect" }));
    }
    const parts = [card];
    const last = reply?.last;
    if (last?.summary) {
      const s = last.summary;
      parts.push(h(
        "div",
        { class: "last" },
        h("span", { text: `Last run: ${plural(s.totalAds, "ad")} \xB7 ${s.pageName ?? describeUrl(last.options.url)} \xB7 ${clockTime(last.heartbeatAt)}` })
      ));
    }
    return parts;
  }
  function runTime(pages) {
    const s = pages * SECONDS_PER_PAGE + (form.measure ? 60 : 0);
    return s < 60 ? `~${Math.max(10, Math.round(s / 10) * 10)} s` : `~${Math.round(s / 60 * 2) / 2} min`;
  }
  function pagesHint() {
    const total = form.mode === "tab" ? tabInfo?.total ?? null : null;
    if (form.maxPages === "all") {
      if (total == null) return "Reads every ad, to the end of the list. Meta's count shows here when you open the popup on the advertiser's Ad Library page.";
      const pages = pagesFor(total);
      const long = pages > LONG_RUN_PAGES ? " A long run: if Meta pauses this connection, it stops and saves everything so far." : "";
      return `Meta shows ~${total.toLocaleString("en-US")} ads: reading all of them, ${runTime(pages)}.${long}`;
    }
    const n = form.maxPages;
    const quick = `Quick look: the ~${n * 30} most-shown ads (Meta lists them first)`;
    if (total == null) return `${quick}, ${runTime(n)}.`;
    return total <= n * 28 ? `Meta shows ~${total.toLocaleString("en-US")} ads: all of them fit, ${runTime(pagesFor(total))}.` : `${quick} of ~${total.toLocaleString("en-US")}, ${runTime(n)}.`;
  }
  async function loadTabInfo() {
    if (!activeTab || !isAdLibraryUrl(activeTab.url)) return;
    try {
      tabInfo = await chrome.tabs.sendMessage(activeTab.id, { type: "page-info" });
    } catch {
      tabInfo = null;
    }
    render();
  }
  function useTab() {
    if (!activeTab) return;
    form.mode = "tab";
    form.input = activeTab.url;
    form.error = null;
    try {
      const u = new URL(activeTab.url);
      const c = u.searchParams.get("country");
      if (c) form.country = c.toUpperCase();
      const status = u.searchParams.get("active_status");
      if (status) form.activeOnly = status !== "all";
    } catch {
    }
  }
  function collect() {
    const target = targetUrl({ input: form.input, country: form.country, activeOnly: form.activeOnly });
    if ("error" in target) {
      form.error = target.error;
      pending = null;
      render();
      return;
    }
    form.country = form.country.trim().toUpperCase() || "ALL";
    savePrefs();
    const options = { url: target.url, maxPages: form.maxPages === "all" ? null : form.maxPages, measure: form.measure };
    const useTabId = form.mode === "tab" && activeTab ? activeTab.id : void 0;
    void preflightAndStart(options, useTabId);
  }
  async function preflightAndStart(options, useTabId) {
    pending = { kind: "checking" };
    render();
    let pf;
    try {
      pf = await send({ type: "preflight", options });
    } catch (e) {
      pending = { kind: "refusal", text: errorText(e, "Couldn't check the run limits") };
      render();
      return;
    }
    if (pf.refusal) {
      pending = { kind: "refusal", text: pf.refusal };
      if (reply && pf.cooldown) reply.cooldown = pf.cooldown;
      render();
      return;
    }
    if (pf.warnings.length) {
      pending = { kind: "warnings", warnings: pf.warnings, options, useTabId };
      render();
      return;
    }
    await start(options, [], useTabId);
  }
  async function start(options, acceptedWarnings, useTabId) {
    pending = { kind: "starting" };
    render();
    try {
      const run = await send({ type: "start", options, acceptedWarnings, ...useTabId != null ? { useTabId } : {} });
      pending = null;
      if (reply && run && typeof run === "object" && "phase" in run) reply.run = run;
    } catch (e) {
      pending = { kind: "refusal", text: errorText(e, "Couldn't start") };
    }
    await refresh();
  }
  function runningView(run) {
    const p = run.progress;
    const measuring = run.phase === "measuring";
    const saving = run.phase === "saving";
    const card = h(
      "div",
      { class: "card" },
      h("p", { class: "status", text: run.status || PHASE_LABEL[run.phase] }),
      h(
        "div",
        { class: "bar", attrs: { role: "progressbar", "aria-valuemin": 0, "aria-valuemax": 100, "aria-valuenow": Math.round(progressFraction(run) * 100) } },
        h("i", { attrs: { style: `width:${(progressFraction(run) * 100).toFixed(1)}%` } })
      ),
      h(
        "div",
        { class: "stats" },
        stat("Ads found", fmt(p.ads)),
        stat("Pages", `${p.pagesLoaded}`, p.toEnd ? p.maxPages ? ` / ~${p.maxPages}` : "" : ` / ${p.maxPages}`),
        stat("Meta's total", p.metaTotal != null ? fmt(p.metaTotal) : "\u2013")
      ),
      h(
        "div",
        { class: "meta-line" },
        h("span", { id: "countdown", text: measuring ? `Media ${p.measured ?? 0} / ${p.toMeasure ?? 0}` : "" }),
        h("span", { id: "elapsed", attrs: { "data-since": run.startedAt }, text: elapsed(run.startedAt) })
      )
    );
    if (run.phase === "consent") {
      card.append(h("div", { class: "callout accent" }, h("span", { text: "Choose a cookie option in the Ad Library tab." })));
    }
    if (run.phase === "paused") {
      card.append(h(
        "div",
        { class: "callout caution" },
        h("span", { text: "Paused: the collector window is minimized or completely covered. Chrome doesn't load results in windows you can't see." }),
        h("div", { class: "actions" }, button("Show the window", "primary", focusRun, { sm: true }))
      ));
      card.append(button("Stop and save", "secondary", stop, { block: true }));
    } else {
      card.append(h(
        "div",
        { class: "row2" },
        button("Show the window", "secondary", focusRun),
        button(saving ? "Saving\u2026" : "Stop and save", "primary", stop, { disabled: saving })
      ));
    }
    return [card, warningsList(run)];
  }
  function stat(label, value, small) {
    return h("div", { class: "stat" }, h("span", { text: label }), h("b", null, value, small ? h("small", { text: small }) : null));
  }
  function tick() {
    const run = reply?.run;
    const cd = document.getElementById("countdown");
    if (cd && run) {
      const left = countdown(run.progress.nextScrollAt);
      const text = run.phase === "collecting" ? left ? `Next scroll in ${left}` : "Waiting for results\u2026" : run.phase === "measuring" ? `Media ${run.progress.measured ?? 0} / ${run.progress.toMeasure ?? 0}` : run.phase === "paused" ? "Waiting for the window" : run.phase === "consent" ? "Waiting for your cookie choice" : run.phase === "opening" ? "Loading the page\u2026" : run.phase === "saving" ? "Building the file\u2026" : "";
      if (cd.textContent !== text) cd.textContent = text;
    }
    const el = document.getElementById("elapsed");
    if (el?.dataset.since) el.textContent = elapsed(Number(el.dataset.since));
    const cl = document.getElementById("cooldown-left");
    if (cl && reply?.cooldown) cl.textContent = duration(reply.cooldown.until - Date.now());
  }
  function summaryBlock(s, saved = true) {
    const t = s.creativeTypes;
    const chips = [
      s.activeAds ? chip(`${fmt(s.activeAds)} active`, "accent") : null,
      t.video ? chip(plural(t.video, "video")) : null,
      t.image ? chip(plural(t.image, "image")) : null,
      t.carousel ? chip(plural(t.carousel, "carousel")) : null,
      t.dco ? chip(`${fmt(t.dco)} dynamic`) : null,
      s.lowImpressionAds ? chip(`${fmt(s.lowImpressionAds)} low impression`) : null,
      s.partnershipAds ? chip(`${fmt(s.partnershipAds)} partnership`) : null,
      s.gatedAds ? chip(`${fmt(s.gatedAds)} age-restricted (no creatives logged out)`, "caution") : null
    ];
    const diff = s.diff ? h(
      "p",
      { class: "diff" },
      h("b", { class: s.diff.added ? "up" : "", text: `${fmt(s.diff.added)} new` }),
      " \xB7 ",
      h("b", { class: s.diff.gone ? "down" : "", text: `${fmt(s.diff.gone)} gone` }),
      " since last run"
    ) : h("p", { class: "diff", text: "First run on this page." });
    return [
      h(
        "div",
        { class: "stack" },
        h("p", { class: "big num", text: `${plural(s.totalAds, "ad")} ${saved ? "saved" : "kept"}` }),
        h("p", { class: "sub", text: `${s.pageName ? `${s.pageName} \xB7 ` : ""}in Downloads/${DOWNLOAD_FOLDER}` }),
        h("p", { class: "sub mono", text: s.fileName, attrs: { title: s.fileName } })
      ),
      chips.some(Boolean) ? h("div", { class: "chips" }, ...chips) : null,
      diff,
      !s.complete && s.stoppedReason ? h("p", { class: "inline-caution", attrs: { style: "margin:0" }, text: `Stopped early: ${s.stoppedReason}` }) : null
    ];
  }
  function appendAll(el, children) {
    for (const c of children) if (c != null && c !== false) el.append(c);
  }
  function chip(text, tone) {
    return h("span", { class: `chip${tone ? ` ${tone}` : ""}`, text });
  }
  function fileButtons(s) {
    return h(
      "div",
      { class: "row2" },
      button("Show in Finder", "primary", showFile, { disabled: s.downloadId == null }),
      button("Open your dashboard", "secondary", () => openDashboard())
    );
  }
  function doneView(run) {
    const s = run.summary;
    if (!s) return [h("div", { class: "card" }, h("p", { class: "status", text: run.status || "Done." }), button("New run", "secondary", clear, { block: true }))];
    const card = h(
      "div",
      { class: "card" },
      ...summaryBlock(s),
      fileButtons(s),
      h(
        "div",
        { class: "steps" },
        h("span", { class: "h", text: "Import it into your dashboard" }),
        h("ol", null, h("li", { text: "Open your dashboard" }), h("li", { text: "Go to Research" }), h("li", { text: "Drag the file from Finder onto the page" }))
      ),
      h("div", { class: "row-end" }, button("New run", "ghost", clear, { sm: true }))
    );
    return [card, warningsList(run)];
  }
  function blockedView(run) {
    const until = run.cooldownUntil ?? reply?.cooldown?.until ?? null;
    const callout = h(
      "div",
      { class: "callout warn" },
      h("span", { class: "t", text: "Meta limited this connection" }),
      run.error ? h("span", { text: run.error }) : null,
      until ? h("span", null, `Next run possible at ${clockTime(until)} (in `, h("span", { id: "cooldown-left", text: duration(until - Date.now()) }), ").") : null,
      h("span", { text: "The extension stopped without trying to get around it. Wait for the cooldown; if it keeps happening, run less often with fewer pages." })
    );
    const card = h("div", { class: "card" }, callout);
    if (run.summary) appendAll(card, [...summaryBlock(run.summary), fileButtons(run.summary)]);
    card.append(h("div", { class: "row-end" }, button("Dismiss", "ghost", clear, { sm: true })));
    return [card, warningsList(run)];
  }
  function failedView(run) {
    const card = h(
      "div",
      { class: "card" },
      h(
        "div",
        { class: "callout warn" },
        h("span", { class: "t", text: "The run didn't finish" }),
        h("span", { text: run.error || run.status || "Something went wrong." })
      )
    );
    if (run.summary) appendAll(card, [...summaryBlock(run.summary), fileButtons(run.summary)]);
    card.append(h(
      "div",
      { class: "row-end" },
      button("Back", "ghost", clear, { sm: true }),
      button("Try again", "primary", () => void retry(run), { sm: true })
    ));
    return [card, warningsList(run)];
  }
  async function act(req, context) {
    try {
      await send(req);
      actionError = null;
    } catch (e) {
      actionError = errorText(e, context);
      render();
    }
  }
  async function stop() {
    await act({ type: "stop" }, "Couldn't stop");
    scheduleRefresh();
  }
  async function focusRun() {
    await act({ type: "focus-run" }, "Couldn't show the window");
  }
  async function showFile() {
    await act({ type: "show-file" }, "Couldn't show the file");
  }
  async function clear() {
    pending = null;
    await act({ type: "clear" }, "Couldn't clear the run");
    await refresh();
  }
  function openDashboard(e) {
    e?.preventDefault();
    void chrome.tabs.create({ url: dashboardAppUrl(dashboardUrl) });
  }
  async function retry(run) {
    await send({ type: "clear" }).catch(() => void 0);
    const sameTab = activeTab && activeTab.id === run.tabId && isAdLibraryUrl(activeTab.url) ? activeTab.id : void 0;
    await refresh();
    await preflightAndStart(run.options, sameTab);
  }
  function savePrefs() {
    try {
      localStorage.setItem(PREFS_KEY, JSON.stringify({ country: form.country, activeOnly: form.activeOnly, maxPages: form.maxPages, measure: form.measure }));
    } catch {
    }
  }
  function loadPrefs() {
    try {
      let saved = localStorage.getItem(PREFS_KEY);
      if (saved === null) {
        saved = localStorage.getItem(EARLIER_PREFS_KEY);
        if (saved !== null) {
          localStorage.setItem(PREFS_KEY, saved);
          localStorage.removeItem(EARLIER_PREFS_KEY);
        }
      }
      const p = JSON.parse(saved ?? "null");
      if (p) {
        if (typeof p.country === "string") form.country = p.country;
        if (typeof p.activeOnly === "boolean") form.activeOnly = p.activeOnly;
        if (PAGE_CHOICES.includes(p.maxPages)) form.maxPages = p.maxPages;
        if (typeof p.measure === "boolean") form.measure = p.measure;
        return;
      }
      for (const key of OLD_PREFS_KEYS) {
        const old = JSON.parse(localStorage.getItem(key) ?? "null");
        if (!old) continue;
        if (typeof old.country === "string") form.country = old.country;
        if (typeof old.activeOnly === "boolean") form.activeOnly = old.activeOnly;
        break;
      }
    } catch {
    }
  }
  function captureFocus() {
    const el = document.activeElement;
    if (!el?.id) return null;
    return { id: el.id, start: el.selectionStart ?? null, end: el.selectionEnd ?? null };
  }
  function restoreFocus(f) {
    if (!f) return;
    const el = document.getElementById(f.id);
    if (!el) return;
    el.focus();
    if (f.start != null && "setSelectionRange" in el) try {
      el.setSelectionRange(f.start, f.end);
    } catch {
    }
  }
  function focusById(id) {
    document.getElementById(id)?.focus();
  }
  async function boot() {
    loadPrefs();
    dashboardUrl = await loadDashboardUrl();
    try {
      const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
      if (tab?.id != null && tab.url) activeTab = { id: tab.id, url: tab.url };
    } catch {
    }
    if (activeTab && isAdLibraryUrl(activeTab.url)) {
      useTab();
      void loadTabInfo();
    }
    chrome.storage.onChanged.addListener((changes, area) => {
      if (area === "session" && "run" in changes || area === "local" && ("cooldown" in changes || "last" in changes || "ledger" in changes)) {
        scheduleRefresh();
      }
      if (area === "local" && DASHBOARD_KEY in changes && !dashboardForm.open) void loadDashboardUrl().then((url) => {
        dashboardUrl = url;
        render();
      });
    });
    setInterval(tick, 250);
    render();
    await refresh();
    if (!isActive(reply?.run) && form.mode === "input") focusById("src");
  }
  void boot();
})();
